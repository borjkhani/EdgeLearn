function [out, P] = train_bptt(N, g, seed, task, opt)
%TRAIN_BPTT  Train all weights of a tanh RNN by backpropagation through time (Adam).
%   h(t) = tanh(W h(t-1) + win*u(t) + b),  y(t) = wout'*h(t) + c.
%   W is initialised as g * N(0,1/N). task.k = recall delay (scalar: target u(t-k));
%   with two delays [k1 k2] the target is the product u(t-k1)*u(t-k2), a nonlinear
%   task. The loss is the mean squared error over steps t > max(k) of a sequence of
%   length opt.T; test errors are normalised by the target variance.
%   Returns the learning curve (normalised test MSE), the number of iterations to
%   reach opt.crit, and the norm of the initial gradient with respect to W. Training
%   stops opt.extra iterations after the criterion is reached. opt.W0 and opt.win0,
%   if given, replace the random initial recurrent and input weights. opt.diag
%   records the gradient norm before clipping at every iteration, the Lyapunov
%   exponent of the current network every 250 iterations, and the error on 2000
%   fresh sequences when the criterion is first reached. opt.freeze_in keeps the
%   input weights fixed. opt.P0 (cell {W, win, b, wout, c}) starts from a trained network.
set_seed(seed);
W = g * randn(N, N) / sqrt(N); win = randn(N, 1); b = zeros(N, 1);
if isfield(opt, 'W0'), W = opt.W0; end        % optional initial network (Experiment F)
if isfield(opt, 'win0'), win = opt.win0; end
if isfield(opt, 'b0'), b = opt.b0; end
wout = zeros(N, 1); c = 0;
P = {W, win, b, wout, c};
if isfield(opt, 'P0'), P = opt.P0; end           % start from a trained network
m = cellfun(@(p) 0 * p, P, 'UniformOutput', false); v = m;
b1 = 0.9; b2 = 0.999; ep = 1e-8; T = opt.T; B = opt.batch; k = task.k;
diag = isfield(opt, 'diag') && opt.diag;
if diag   % random numbers for the diagnostics, drawn before the training stream
  set_seed(seed + 2000); Ui = 2 * rand(T, 2000) - 1; Dl.u = 2 * rand(1, 2000) - 1; Dl.v = randn(size(W, 1), 1);
end
set_seed(seed + 1000); Ut = 2 * rand(T, 500) - 1;           % fixed test set
curve = nan(1, opt.iters); it_hit = NaN; g0 = NaN;
out.err_init = lossgrad(P, Ut, k) / (1/3)^numel(k);   % test error before any update
if diag, gnorm = nan(1, opt.iters); lam_t = []; lam_it = []; out.indep_hit = NaN; end
frozen = isfield(opt, 'freeze_in') && opt.freeze_in;
for it = 1:opt.iters
    U = 2 * rand(T, B) - 1;
    [L, G] = lossgrad(P, U, k);
    if it == 1, g0 = norm(G{1}, 'fro'); end
    % gradient clipping (global norm) keeps the comparison fair across gains
    gn = sqrt(sum(cellfun(@(x) sum(x(:).^2), G)));
    if diag, gnorm(it) = gn; end
    if frozen, G{2} = 0 * G{2}; end                         % input weights fixed
    if gn > opt.clip, G = cellfun(@(x) x * opt.clip / gn, G, 'UniformOutput', false); end
    for j = 1:5
        m{j} = b1 * m{j} + (1 - b1) * G{j}; v{j} = b2 * v{j} + (1 - b2) * G{j}.^2;
        P{j} = P{j} - opt.lr * (m{j} / (1 - b1^it)) ./ (sqrt(v{j} / (1 - b2^it)) + ep);
    end
    if mod(it, opt.every) == 0 || it == 1
        Lt = lossgrad(P, Ut, k); curve(it) = Lt / (1/3)^numel(k);   % target variance
        if isnan(it_hit) && curve(it) < opt.crit
            it_hit = it;
            if diag   % independent evaluation on fresh sequences, never used for stopping
                out.indep_hit = lossgrad(P, Ui, k) / (1/3)^numel(k);
            end
        end
    end
    if diag && (it == 1 || mod(it, 250) == 0)
        lam_t(end + 1) = lyap_param(P, Dl); lam_it(end + 1) = it; %#ok<AGROW>
    end
    if ~isnan(it_hit) && it >= it_hit + opt.extra, break; end   % early stop
end
if diag, out.gnorm = gnorm; out.lam_t = lam_t; out.lam_it = lam_it; end
out.curve = curve; out.it_hit = it_hit; out.grad0 = g0; out.final = curve(find(isfinite(curve), 1, 'last')); out.iters_run = it;
end

function lam = lyap_param(P, Dl)
% conditional Lyapunov exponent of the current network (with its bias), on a
% fixed input sequence so that values are comparable during training
[W, win, b] = P{1:3}; N = size(W, 1);
h = zeros(N, 1); v = Dl.v / norm(Dl.v); ls = 0; T = numel(Dl.u);
for t = 1:T
  h = tanh(W * h + win * Dl.u(t) + b); v = (1 - h.^2) .* (W * v); n = norm(v); v = v / n;
  if t > 300, ls = ls + log(n); end
end
lam = ls / (T - 300);
end

function [L, G] = lossgrad(P, U, k)
[W, win, b, wout, c] = P{:};
[T, B] = size(U); N = size(W, 1);
H = zeros(N, B, T + 1);
for t = 1:T
    H(:, :, t + 1) = tanh(W * H(:, :, t) + win * U(t, :) + b);
end
idx = (max(k) + 1):T; n = numel(idx) * B;
L = 0; dH = zeros(N, B, T + 1); dwout = zeros(N, 1); dc = 0;
for t = idx
    e = wout' * H(:, :, t + 1) + c - prod(U(t - k, :), 1);
    L = L + sum(e.^2);
    dH(:, :, t + 1) = wout * (2 * e / n);
    dwout = dwout + H(:, :, t + 1) * (2 * e / n)'; dc = dc + sum(2 * e / n);
end
L = L / n;
if nargout < 2, return; end
dW = zeros(N); dwin = zeros(N, 1); db = zeros(N, 1); dh = zeros(N, B);
for t = T:-1:1
    dh = dh + dH(:, :, t + 1);
    da = dh .* (1 - H(:, :, t + 1).^2);
    dW = dW + da * H(:, :, t)'; dwin = dwin + da * U(t, :)'; db = db + sum(da, 2);
    dh = W' * da;
end
G = {dW, dwin, db, dwout, dc};
end
