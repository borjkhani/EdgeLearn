function lam = lyap_rnn(W, win, s, b)
%LYAP_RNN  Conditional maximal Lyapunov exponent (per step) of h = tanh(W h + win u)
%   driven by i.i.d. U(-1,1) input, from the exact tangent map (3000 steps, first
%   500 discarded). Optional bias b. Used for Experiments B and D-F.
if nargin < 4, b = 0; end
set_seed(s + 500); N = size(W, 1); h = zeros(N, 1); v = randn(N, 1); v = v / norm(v); ls = 0; T = 3000;
for t = 1:T
  h = tanh(W * h + win * (2 * rand - 1) + b); v = (1 - h.^2) .* (W * v); n = norm(v); v = v / n;
  if t > 500, ls = ls + log(n); end
end
lam = ls / (T - 500);
end
