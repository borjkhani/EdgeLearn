function set_seed(s)
%SET_SEED  Seed rand and randn identically in MATLAB and GNU Octave.
if exist('OCTAVE_VERSION', 'builtin')
    rand('state', s); randn('state', s);
else
    rng(s, 'twister');
end
end
