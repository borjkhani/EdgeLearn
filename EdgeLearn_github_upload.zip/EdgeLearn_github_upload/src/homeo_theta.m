function th = homeo_theta(W, win, amp, target, seed, b)
%HOMEO_THETA  Homeostatic scaling factor of the recurrent weights.
%   Finds theta such that the network h = tanh(theta*W*h + amp*win*u), driven by
%   i.i.d. U(-1,1) input u, has mean squared activity equal to target (bisection
%   on [0.2, 6]). Models multiplicative synaptic up- or down-scaling that restores
%   the activity level after the input amplitude has changed. Optional b: biases.
if nargin < 6, b = zeros(size(W, 1), 1); end
lo = 0.2; hi = 6;
for it = 1:30
  th = sqrt(lo * hi);
  if act_level(th * W, win, amp, seed, b) < target, lo = th; else, hi = th; end
end
end

function m = act_level(W, win, amp, seed, b)
set_seed(seed + 300); N = size(W, 1); h = zeros(N, 1); T = 3000; acc = 0;
for t = 1:T
  h = tanh(W * h + amp * win * (2 * rand - 1) + b);
  if t > 500, acc = acc + mean(h.^2); end
end
m = acc / (T - 500);
end
