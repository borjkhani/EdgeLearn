function net = make_net(N, g, seed)
%MAKE_NET  Random tanh reservoir: x(t+1) = tanh(g*W*x(t) + win*u(t) + b) + noise.
%   W has i.i.d. N(0,1/N) entries, so its spectral radius is close to 1 and g sets
%   the gain. Input weights and biases are fixed and drawn with the same seed.
set_seed(seed);
net.N = N; net.g = g;
net.W = randn(N, N) / sqrt(N);
net.win = (2 * rand(N, 1) - 1);
net.b = 0.1 * randn(N, 1);
net.sig_in = 0.5;      % input scaling
net.sig_n = 1e-3;      % state noise
end
