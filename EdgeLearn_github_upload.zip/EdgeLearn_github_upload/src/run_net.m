function [X, lam] = run_net(net, u, seed, washout)
%RUN_NET  Drive the network with input u (1 x T); return states X (N x T-washout)
%   and the conditional maximal Lyapunov exponent lam (per step), computed with the
%   exact tangent map along the driven, noisy trajectory.
set_seed(seed + 7919);
N = net.N; T = numel(u); A = net.g * net.W;
x = zeros(N, 1); v = randn(N, 1); v = v / norm(v); ls = 0;
X = zeros(N, T - washout);
for t = 1:T
    pre = A * x + net.sig_in * net.win * u(t) + net.b;
    x = tanh(pre) + net.sig_n * randn(N, 1);
    v = (1 - tanh(pre).^2) .* (A * v);
    nv = norm(v); v = v / nv;
    if t > washout, ls = ls + log(nv); X(:, t - washout) = x; end
end
lam = ls / (T - washout);
end
