#!/bin/bash
# usage: ./launch.sh "expB_bptt" 2   -> runs parts 1..n in background
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
cd "$(dirname "$0")/experiments"
for p in $(seq 1 $2); do
  nohup octave --no-gui -q --eval "$1($p,$2)" > ../results/${1}_log$p.txt 2>&1 &
done
