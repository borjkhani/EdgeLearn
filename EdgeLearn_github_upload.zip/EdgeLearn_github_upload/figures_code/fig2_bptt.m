function fig2_bptt()
%FIG2_BPTT  Whole-network learning (backpropagation through time) from different
%   initial gains. Delayed recall of a random input with delay k.
%   a  learning curves, delay 20 (median over 8 networks)
%   b  iterations to reach test NMSE < 0.1 versus initial gain, delays 5-30;
%      median and interquartile range over 8 networks; crosses: criterion not
%      reached by the majority within the budget
%   c  the same versus the initial Lyapunov exponent (log scale)
%   d  Lyapunov exponent of the fastest-learning network versus delay (median and
%      range over networks that learned the task). Grey dashed: lambda* = -c/k fitted
%      to delays 5-20; open circle: its prediction for delay 30, made before the
%      delay-30 results were analysed (results/prediction_k30.txt), which failed
here = fileparts(mfilename('fullpath')); S = fig_style(); fh = figure('Visible', 'off', 'Color', 'w');
B = load_runs('expB'); E = load_runs('expE');
% fine-resolution delay 5 from Experiment E replaces delay 5 of Experiment B
B5 = B.k == 5; F = fieldnames(B);
for i = 1:numel(F), B.(F{i}) = B.(F{i})(~B5); end
D = B; for i = 1:numel(F), D.(F{i}) = [B.(F{i}); E.(F{i})]; end
kc = [0.10 0.27 0.55; 0.106 0.60 0.42; 0.93 0.55 0.10; 0.70 0.12 0.12];
ks = [5 10 20 30]; ks = ks(arrayfun(@(k) any(D.k == k), ks));
for j = 1:numel(ks), Q{j} = sweet_spot(D, ks(j)); end %#ok<AGROW>
% a: learning curves, delay 20
ax = subplot(2, 2, 1); hold(ax, 'on'); gsel = [0.3 0.7 1.2 1.6 2.0]; cm = gain_cmap(numel(gsel)); hh = [];
for j = 1:numel(gsel)
  r = find(D.k == 20 & abs(D.g - gsel(j)) < 1e-9); M = nan(numel(r), 3000);
  for i = 1:numel(r)
    c = D.curve{r(i)}; c = c(1:min(end, 3000)); ok = isfinite(c); it = find(ok); v = c(ok);
    last = it(end); M(i, 1:numel(c)) = interp1(it, v, 1:numel(c));
    M(i, last + 1:end) = v(end);          % runs stopped early keep their final error
  end
  x = 25:25:3000; hh(j) = plot(ax, x, median(M(:, x), 1), 'Color', cm(j, :), 'LineWidth', S.lw); %#ok<AGROW>
end
line(ax, [0 3000], [0.1 0.1], 'Color', S.ink2, 'LineStyle', '--');
set(ax, 'YScale', 'log'); ylim(ax, [0.005 2]); xlim(ax, [0 3000]);
xlabel(ax, 'training iteration'); ylabel(ax, 'validation error (NMSE)');
legend(ax, hh, arrayfun(@(g) sprintf('g = %.1f', g), gsel, 'UniformOutput', false), 'Location', 'east', 'Box', 'off', 'FontSize', S.fs - 2);
style_axes(ax, 'a  learning to recall 20 steps back');
% b and c: time to learn versus gain and versus lambda
for p = 1:2
  ax = subplot(2, 2, p + 1); hold(ax, 'on'); hl = [];
  for j = 1:numel(ks)
    q = Q{j}; x = q.gs; if p == 2, x = q.lam; end
    ok = q.nsolved > q.n / 2; top = 6000 * 1.5;
    for i = find(ok), line(ax, x(i) * [1 1], [q.q25(i) min(q.q75(i), top)], 'Color', 0.5 * kc(j, :) + 0.5, 'LineWidth', 1.2); end
    hl(j) = plot(ax, x(ok), q.med(ok), ['-' S.mk{j}], 'Color', kc(j, :), 'MarkerFaceColor', kc(j, :), 'MarkerSize', S.ms, 'LineWidth', S.lw); %#ok<AGROW>
    plot(ax, x(~ok), top * ones(1, sum(~ok)), 'x', 'Color', kc(j, :), 'MarkerSize', S.ms + 2, 'LineWidth', 1.4);
  end
  set(ax, 'YScale', 'log'); ylim(ax, [5 2e4]);
  text(ax, 0.02, 0.97, 'x: not learned', 'Units', 'normalized', 'FontSize', S.fs - 2, 'Color', S.ink2);
  ylabel(ax, 'iterations to learn');
  if p == 1
    xlim(ax, [0.2 2.6]); xlabel(ax, 'initial gain g');
    legend(ax, hl, arrayfun(@(k) sprintf('delay %d', k), ks, 'UniformOutput', false), 'Location', 'south', 'Orientation', 'horizontal', 'Box', 'off', 'FontSize', S.fs - 2);
    style_axes(ax, 'b  how fast does a network learn?');
  else
    xlim(ax, [-1.4 0.25]); line(ax, [0 0], [5 2e4], 'Color', S.ink2, 'LineStyle', '--');
    text(ax, 0.01, 12, 'edge', 'Color', S.ink2, 'FontSize', S.fs - 1);
    xlabel(ax, 'initial Lyapunov exponent \lambda (per step)'); style_axes(ax, 'c  ... as a function of \lambda');
  end
end
% d: lambda* vs delay; the -c/k rule fitted to delays 5-20 and its failed
% out-of-sample prediction for delay 30
ax = subplot(2, 2, 4); hold(ax, 'on');
cfit = []; for j = 1:3, l = Q{j}.lamstar; cfit = [cfit, -l(isfinite(l)) * ks(j)]; end %#ok<AGROW>
c = median(cfit); kk = linspace(3, 36, 200);
plot(ax, kk, -c ./ kk, '--', 'Color', [0.6 0.6 0.6], 'LineWidth', 1.2);
lm = nan(1, numel(ks));
for j = 1:numel(ks)
  l = Q{j}.lamstar; l = l(isfinite(l)); lm(j) = median(l);
  line(ax, ks(j) * [1 1], [min(l) max(l)], 'Color', 0.5 * kc(j, :) + 0.5, 'LineWidth', 2);
end
plot(ax, ks, lm, '-', 'Color', S.ink2, 'LineWidth', 1);
for j = 1:numel(ks)
  plot(ax, ks(j), lm(j), S.mk{j}, 'Color', kc(j, :), 'MarkerFaceColor', kc(j, :), 'MarkerSize', S.ms + 2, 'LineWidth', 1.6);
end
if any(ks == 30)
  plot(ax, 30, -c / 30, 'o', 'Color', S.ink, 'MarkerFaceColor', 'w', 'MarkerSize', S.ms + 3, 'LineWidth', 1.4);
  text(ax, 21.5, -c / 30 + 0.045, 'predicted', 'FontSize', S.fs - 2, 'Color', S.ink);
  text(ax, 31.5, lm(ks == 30) - 0.03, 'observed', 'FontSize', S.fs - 2, 'Color', kc(ks == 30, :));
end
line(ax, [0 36], [0 0], 'Color', S.ink2, 'LineStyle', '--');
text(ax, 2, 0.03, 'edge of chaos', 'Color', S.ink2, 'FontSize', S.fs - 2);
text(ax, 12, -0.5, sprintf('grey dashed: \\lambda^* = -%.1f/k,', c), 'Color', [0.45 0.45 0.45], 'FontSize', S.fs - 2);
text(ax, 12, -0.55, 'fitted to delays 5-20', 'Color', [0.45 0.45 0.45], 'FontSize', S.fs - 2);
xlim(ax, [0 36]); ylim(ax, [-0.6 0.07]); xlabel(ax, 'delay k (steps)'); ylabel(ax, '\lambda of the fastest learner');
style_axes(ax, 'd  the sweet spot stops short of the edge');
save_fig(fh, 'Fig2_learning_speed', 17, 13); close(fh);
end
