function fig1_concept()
%FIG1_CONCEPT  Three regimes of a random recurrent network.
%   a-c activity of four units (offset) for three gains: random input for 40 steps,
%       then input off
%   d   conditional Lyapunov exponent versus gain: fixed network of 200 units with
%       input as used for readout learning (Experiment A), and the 64-unit networks
%       trained by backpropagation (Experiment B, at initialisation); mean +- s.d.
%   e   how strongly an error signal tau steps later reaches the present: geometric
%       mean norm of a perturbation propagated through tau Jacobians (Experiment C)
here = fileparts(mfilename('fullpath')); addpath(fullfile(here, '..', 'src'));
S = fig_style(); fh = figure('Visible', 'off', 'Color', 'w');
load(fullfile(here, '..', 'results', 'expC_gradients.mat'), 'R'); C = R;
lab = {'fast forgetting', 'slow fading', 'self-sustained'}; cm3 = [0.10 0.27 0.55; 0.106 0.60 0.42; 0.70 0.12 0.12];
for a = 1:3
  ax = subplot(2, 3, a); hold(ax, 'on');
  H = C.ex{a}; t = 1:size(H, 2);
  patch(ax, [0 C.ex_off C.ex_off 0], [-1 -1 7 7], [0.94 0.94 0.94], 'EdgeColor', 'none');
  for i = 1:size(H, 1), plot(ax, t, H(i, :) + 2 * (i - 1), 'Color', cm3(a, :), 'LineWidth', 1.1); end
  text(ax, 4, 7.4, 'input', 'FontSize', S.fs - 2, 'Color', S.ink2);
  text(ax, C.ex_off + 6, 7.4, 'no input', 'FontSize', S.fs - 2, 'Color', S.ink2);
  xlim(ax, [0 160]); ylim(ax, [-1.2 8]); set(ax, 'YTick', []); xlabel(ax, 'time step');
  if a == 1, ylabel(ax, 'activity of 4 units'); end
  style_axes(ax, sprintf('%s  g = %g, %s', char('a' + a - 1), C.ex_g(a), lab{a}));
end
% d: lambda vs g
ax = subplot(2, 3, [4 5]); hold(ax, 'on');
load(fullfile(here, '..', 'results', 'expA_reservoir.mat'), 'R'); A = R;
m = mean(A.lam_cond, 2); sd = std(A.lam_cond, 0, 2);
patch(ax, [A.gs fliplr(A.gs)], [m' - sd' fliplr(m' + sd')], 0.8 * [1 1 1] + 0.2 * S.col(1, :), 'EdgeColor', 'none');
h1 = plot(ax, A.gs, m, '-o', 'Color', S.col(1, :), 'MarkerFaceColor', S.col(1, :), 'MarkerSize', S.ms - 1, 'LineWidth', S.lw);
B = load_runs('expB'); gB = unique(B.g)'; mB = arrayfun(@(g) mean(B.lam0(B.g == g & B.k == 5)), gB);
sB = arrayfun(@(g) std(B.lam0(B.g == g & B.k == 5)), gB);
for j = 1:numel(gB), line(ax, gB(j) * [1 1], mB(j) + [-1 1] * sB(j), 'Color', S.col(2, :), 'LineWidth', 1); end
h2 = plot(ax, gB, mB, '-s', 'Color', S.col(2, :), 'MarkerFaceColor', S.col(2, :), 'MarkerSize', S.ms - 1, 'LineWidth', S.lw);
line(ax, [0.2 2.6], [0 0], 'Color', S.ink2, 'LineStyle', '--');
text(ax, 1.75, 0.3, 'chaotic  (\lambda > 0)', 'Color', S.ink2, 'FontSize', S.fs - 1);
text(ax, 1.75, -0.32, 'ordered  (\lambda < 0)', 'Color', S.ink2, 'FontSize', S.fs - 1);
xlim(ax, [0.2 2.6]); ylim(ax, [-1.5 0.4]); xlabel(ax, 'gain g'); ylabel(ax, '\lambda (per step)');
legend(ax, [h1 h2], {'N = 200, readout learning', 'N = 64, whole-network learning'}, 'Location', 'southeast', 'Box', 'off');
style_axes(ax, 'd  largest Lyapunov exponent of the driven network');
% e: error-signal reach
ax = subplot(2, 3, 6); hold(ax, 'on'); cm = gain_cmap(numel(C.gs)); hh = [];
for a = 1:numel(C.gs)
  hh(a) = plot(ax, C.taus, C.lognorm(a, :) / log(10), 'Color', cm(a, :), 'LineWidth', S.lw); %#ok<AGROW>
end
xlim(ax, [0 70]); ylim(ax, [-8 6]); xlabel(ax, 'steps back in time \tau'); ylabel(ax, 'log_{10} amplification');
for a = 1:numel(C.gs)
  y = C.lognorm(a, end) / log(10); xt = 61; if y < -8, xt = interp1(C.lognorm(a, :) / log(10), C.taus, -7.6) + 1; y = -7.6; end
  text(ax, xt, y, sprintf(' %.1f', C.gs(a)), 'Color', cm(a, :), 'FontSize', S.fs - 2);
end
text(ax, 2, 5.2, 'labels: gain g', 'FontSize', S.fs - 2, 'Color', S.ink2);
style_axes(ax, 'e  how far back can learning reach?');
save_fig(fh, 'Fig1_regimes', 17, 11.5 + 1.5 * ~isempty(getenv('NECO_FIGS'))); close(fh);
end
