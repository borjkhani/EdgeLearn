function predict_k30()
%PREDICT_K30  Fit lambda* = -c/k to the fastest-learning networks for delays 5, 10
%   and 20 (Experiments B and E, delay 5 at fine resolution) and write the
%   predicted sweet spot for delay 30 to results/prediction_k30.txt. Run while the
%   delay-30 runs are in progress; the fit uses no delay-30 data.
here = fileparts(mfilename('fullpath'));
B = load_runs('expB'); E = load_runs('expE'); F = fieldnames(B);
keep = B.k ~= 5; for i = 1:numel(F), B.(F{i}) = B.(F{i})(keep); end
keep = E.k == 5; for i = 1:numel(F), E.(F{i}) = E.(F{i})(keep); end
D = B; for i = 1:numel(F), D.(F{i}) = [B.(F{i}); E.(F{i})]; end
cs = []; for k = [5 10 20], Q = sweet_spot(D, k); cs = [cs, -Q.lamstar(isfinite(Q.lamstar)) * k]; end %#ok<AGROW>
c = median(cs); lp = -c / 30;
% gain at which the mean initial exponent equals the prediction (Experiment B, k = 10 runs)
gs = unique(D.g)'; lm = arrayfun(@(g) mean(D.lam0(D.g == g & D.k == 10)), gs);
gp = interp1(lm, gs, lp);
f = fopen(fullfile(here, '..', 'results', 'prediction_k30.txt'), 'w');
fprintf(f, 'Prediction written %s, while the delay-30 runs were in progress (the fit uses only delays 5, 10, 20).\n', datestr(now));
fprintf(f, 'c = median(-lambda* k) over 24 network-delay pairs (k = 5, 10, 20) = %.2f\n', c);
fprintf(f, 'predicted lambda* for k = 30: %.3f per step, i.e. initial gain g = %.2f\n', lp, gp);
fclose(f); type(fullfile(here, '..', 'results', 'prediction_k30.txt'));
end
