function c = gain_cmap(n)
%GAIN_CMAP  Ordered colours from deep blue (low gain, ordered) to red (chaotic).
k = [0.10 0.27 0.55; 0.33 0.62 0.85; 0.55 0.55 0.55; 0.93 0.55 0.25; 0.70 0.12 0.12];
c = interp1(linspace(0, 1, size(k, 1)), k, linspace(0, 1, n));
end
