function stats_for_text()
%STATS_FOR_TEXT  Print every number quoted in the manuscript.
here = fileparts(mfilename('fullpath')); addpath(fullfile(here, '..', 'src'));
load(fullfile(here, '..', 'results', 'expA_reservoir.mat'), 'R'); A = R;
B = load_runs('expB'); E = load_runs('expE'); F = fieldnames(B);
B5 = B; keep = B.k ~= 5; for i = 1:numel(F), B.(F{i}) = B.(F{i})(keep); end
D = B; for i = 1:numel(F), D.(F{i}) = [B.(F{i}); E.(F{i})]; end
printf('=== Lyapunov exponents ===\n');
lamA = mean(A.lam_cond, 2)'; printf('N=200 driven: edge (lambda=0) at g = %.2f; lambda_aut edge at g = %.2f\n', ...
  interp1(lamA, A.gs, 0), interp1(mean(A.lam_aut, 2)', A.gs, 0));
gs = unique(B5.g)'; lB = arrayfun(@(g) mean(B5.lam0(B5.g == g)), gs);
printf('N=64 driven: edge at g = %.2f\n', interp1(lB, gs, 0));
printf('lambda(g) N=64: %s\n', sprintf('%.1f:%.3f ', [gs; lB]));
printf('\n=== Reservoir (Experiment A) ===\n');
mc = mean(sum(A.MCk, 3), 2)'; [m, i] = max(mc);
printf('max MC %.1f at g = %.1f (lambda %.3f); MC at edge-nearest g=1.3: %.1f; at g=2.0: %.1f; at g=0.5: %.1f\n', m, A.gs(i), lamA(i), mc(A.gs == 1.3), mc(abs(A.gs - 2) < 1e-9), mc(A.gs == 0.5));
for j = 1:2
  T = squeeze(A.tlearn(:, :, j)); md = median(T, 2)'; [mn, i] = min(md);
  ok = A.gs(isfinite(md)); printf('LMS delay %d: fastest median %g samples at g = %s; learned (median finite) for g in %.1f-%.1f\n', ...
     A.kl(j), mn, sprintf('%.1f ', A.gs(md == mn)), min(ok), max(ok));
end
T3 = A.tlearn(:, :, 3); printf('LMS delay 20: learned in %d of %d networks x gains\n', sum(isfinite(T3(:))), numel(T3));
pr = mean(A.PR, 2)'; printf('participation ratio: g=0.5 %.1f, g=1.1 %.1f, g=1.3 %.1f, g=2.0 %.1f, g=2.5 %.1f\n', pr(A.gs == 0.5), pr(abs(A.gs - 1.1) < 1e-9), pr(abs(A.gs - 1.3) < 1e-9), pr(abs(A.gs - 2) < 1e-9), pr(end));
printf('\n=== Whole-network learning (Experiments B, E) ===\n');
cs = [];
for k = [5 10 20 30]
  Q = sweet_spot(D, k);
  printf('delay %d: per-gain median iterations %s\n', k, sprintf('%.1f:%g ', [Q.gs; Q.med]));
  printf('   solved (of %d): %s\n', Q.n, sprintf('%.1f:%d ', [Q.gs; Q.nsolved]));
  printf('   g* median %.2f (range %.2f-%.2f); lambda* median %.3f (range %.3f to %.3f)\n', nmed(Q.gstar), min(Q.gstar), max(Q.gstar), nmed(Q.lamstar), min(Q.lamstar), max(Q.lamstar));
  [mn, ib] = min(Q.med); ie = find(abs(Q.gs - 1.6) < 1e-9);
  if ~isempty(ie), printf('   best median %g at g=%.1f; at g=1.6 (lambda %.3f) %g (ratio %.1f)\n', mn, Q.gs(ib), Q.lam(ie), Q.med(ie), Q.med(ie) / mn); end
  if k <= 20, cs = [cs, -Q.lamstar(isfinite(Q.lamstar)) * k]; end %#ok<AGROW>
  if k == 30
    c = median(cs); printf('   fit c = %.2f -> predicted lambda* %.3f; observed median %.3f (n = %d networks)\n', c, -c / 30, nmed(Q.lamstar), sum(isfinite(Q.lamstar)));
    % bootstrap over networks for the observed median
    ls_ = Q.lamstar(isfinite(Q.lamstar)); set_seed(1); bs = arrayfun(@(i) median(ls_(randi(numel(ls_), 1, numel(ls_)))), 1:2000);
    bs = sort(bs); printf('   observed lambda* 95%% bootstrap CI %.3f to %.3f\n', bs(51), bs(1950));
  end
end
printf('-lambda* k pooled (k=5,10,20): median %.2f, IQR %.2f-%.2f, n=%d\n', median(cs), prc(cs, 25), prc(cs, 75), numel(cs));
% bootstrap interval of the fitted prediction: resample networks (seeds) jointly across
% delays, because the same eight networks were used for every delay
Qs = {sweet_spot(D, 5), sweet_spot(D, 10), sweet_spot(D, 20)}; set_seed(3); pr = zeros(1, 2000); kk = [5 10 20];
for b = 1:2000
  ii = randi(8, 1, 8); cc = [];
  for j = 1:3, l = Qs{j}.lamstar(ii); l = l(isfinite(l)); cc = [cc, -l * kk(j)]; end %#ok<AGROW>
  pr(b) = -median(cc) / 30;
end
pr = sort(pr); printf('bootstrap 95%% interval of the fitted prediction (k=30, seeds resampled jointly): %.3f to %.3f\n', pr(51), pr(1950));
threshold_sensitivity(D);
stats_vision();
stats_pretrained();
stats_diagnostics();
stats_feasibility();
printf('\n=== Robustness (Experiment D) ===\n');
Dd = load_runs('expD'); cn = unique(Dd.cond)';
for j = 1:numel(cn)
  r = strcmp(Dd.cond, cn{j}); gs = unique(Dd.g(r))'; md = arrayfun(@(g) median(Dd.hit(r & Dd.g == g)), gs);
  ns = arrayfun(@(g) sum(isfinite(Dd.hit(r & Dd.g == g))), gs); [mn, i] = min(md);
  printf('%-8s best median %g at g = %s | medians %s | solved %s\n', cn{j}, mn, sprintf('%.1f ', gs(md == mn)), sprintf('%g ', md), sprintf('%d ', ns));
end
end

function m = nmed(x)
m = median(x(isfinite(x)));
end

function p = prc(x, q)
x = sort(x(:)); r = 1 + (numel(x) - 1) * q / 100; p = x(floor(r)) + (r - floor(r)) * (x(ceil(r)) - x(floor(r)));
end

function stats_vision()
here = fileparts(mfilename('fullpath'));
d = dir(fullfile(here, '..', 'results', 'expF', 'run_*.mat')); X = [];
for i = 1:numel(d)
  o = load(fullfile(d(i).folder, d(i).name)); o = o.o; h = o.it_hit; if isnan(h), h = Inf; end
  X(end + 1, :) = [o.amp o.adapted o.k o.seed h o.lam0 o.theta o.lam_depr]; %#ok<AGROW>
end
printf('\n=== Vision (Experiment F) ===\n');
r1 = X(:, 2) == 1 & X(:, 1) == 1 & X(:, 3) == 10; r0 = X(:, 2) == 0 & X(:, 1) == 1 & X(:, 3) == 10;
printf('theta: median %.2f range %.2f-%.2f\n', median(X(r1, 7)), min(X(r1, 7)), max(X(r1, 7)));
printf('lambda deprived before scaling: median %.3f (range %.3f to %.3f); after: median %.3f (range %.3f to %.3f); after > 0 in %d/8\n', ...
  median(X(r0, 8)), min(X(r0, 8)), max(X(r0, 8)), median(X(r1, 8)), min(X(r1, 8)), max(X(r1, 8)), sum(X(r1, 8) > 0));
N = 64; lh = zeros(1, 8); for s = 1:8, set_seed(s); W = randn(N) / sqrt(N); win = randn(N, 1); lh(s) = lyap_rnn(W, win, s); end
printf('lambda healthy (natural input): median %.3f range %.3f to %.3f\n', median(lh), min(lh), max(lh));
for k = [10 20]
  for a = [0.25 0.5 1]
    h0 = X(X(:, 1) == a & X(:, 2) == 0 & X(:, 3) == k, 5); h1 = X(X(:, 1) == a & X(:, 2) == 1 & X(:, 3) == k, 5);
    printf('k=%d a=%.2f: median reversed %g kept %g; lambda restored (median) reversed %.3f kept %.3f (max %.3f)\n', k, a, median(h0), median(h1), ...
      median(X(X(:, 1) == a & X(:, 2) == 0 & X(:, 3) == k, 6)), median(X(X(:, 1) == a & X(:, 2) == 1 & X(:, 3) == k, 6)), max(X(X(:, 1) == a & X(:, 2) == 1 & X(:, 3) == k, 6)));
    printf('     per-network ratios kept/reversed: %s\n', sprintf('%.2f ', h1 ./ h0));
  end
  R = []; for s = 1:8, for a = [0.25 0.5 1]
    h0 = X(X(:, 1) == a & X(:, 2) == 0 & X(:, 3) == k & X(:, 4) == s, 5); h1 = X(X(:, 1) == a & X(:, 2) == 1 & X(:, 3) == k & X(:, 4) == s, 5);
    R(end + 1, :) = [X(X(:, 2) == 1 & X(:, 4) == s & X(:, 1) == a & X(:, 3) == k, 7) h1 / h0]; %#ok<AGROW>
  end, end
  rho = corr(tiedrank_(R(:, 1)), tiedrank_(R(:, 2))); printf('   Spearman(theta, ratio) over all points = %.2f (n = %d, 3 per network)\n', rho, size(R, 1));
  % one value per network: geometric mean ratio over the three signal strengths
  tn = R(1:3:end, 1); gm = exp(mean(reshape(log(R(:, 2)), 3, []), 1))';
  rn = corr(tiedrank_(tn), tiedrank_(gm));
  set_seed(2); bs = zeros(1, 2000); for b = 1:2000, i = randi(8, 1, 8); bs(b) = corr(tiedrank_(tn(i)), tiedrank_(gm(i))); end
  nd = sum(~isfinite(bs)); bs = sort(bs(isfinite(bs))); nb = numel(bs);
  printf('   per network: theta %s | geo-mean ratio %s | Spearman %.2f (bootstrap 95%% CI %.2f to %.2f); overall geo-mean ratio %.2f; %d undefined resamples dropped\n', ...
     sprintf('%.2f ', tn), sprintf('%.2f ', gm), rn, bs(max(1, round(0.025 * nb))), bs(round(0.975 * nb)), exp(mean(log(gm))), nd);
end
end

function r = tiedrank_(x)
[~, ~, j] = unique(x); c = accumarray(j, 1); cs = cumsum(c); avg = cs - (c - 1) / 2; r = avg(j);
end

function threshold_sensitivity(D)
% iterations to reach other NMSE criteria, from the stored learning curves; runs
% stopped before reaching a criterion are treated as not reaching it (censored)
printf('\n=== Threshold sensitivity (Experiments B, E) ===\n');
for crit = [0.2 0.1 0.05]
  for k = [5 10 20 30]
    r = find(D.k == k); H = inf(numel(r), 1);
    for i = 1:numel(r)
      c = D.curve{r(i)}; it = find(isfinite(c) & c < crit, 1); if ~isempty(it), H(i) = it; end
    end
    gs = unique(D.g(r))'; md = arrayfun(@(g) median(H(D.g(r) == g)), gs); [mn, ib] = min(md);
    printf('crit %.2f k=%d: fastest median %g at g = %s; medians %s\n', crit, k, mn, sprintf('%.1f ', gs(md == mn)), sprintf('%.1f:%g ', [gs; md]));
  end
end
end

function stats_pretrained()
here = fileparts(mfilename('fullpath')); od = fullfile(here, '..', 'results', 'expF2');
d = dir(fullfile(od, 'run_*.mat')); X = [];
for i = 1:numel(d)
  o = load(fullfile(d(i).folder, d(i).name)); o = o.o; h = o.it_hit; if isnan(h), h = Inf; end
  X(end + 1, :) = [o.new_code o.kept o.amp o.frozen o.seed h o.theta]; %#ok<AGROW>
end
printf('\n=== Vision, pretrained networks (Experiment F2) ===\n');
P = zeros(8, 5); for s = 1:8, L = load(fullfile(od, sprintf('pretrained_%d.mat', s))); P(s, :) = [L.Pt.hit L.Pt.lam_trained L.Pt.lam_depr0 L.Pt.lam_depr L.Pt.theta]; end
printf('pretraining iterations median %g (range %g-%g)\n', median(P(:, 1)), min(P(:, 1)), max(P(:, 1)));
printf('lambda trained median %.3f; deprived %.3f; deprived+scaled %.3f (range %.3f to %.3f, >0 in %d/8); theta median %.2f range %.2f-%.2f\n', ...
  median(P(:, 2)), median(P(:, 3)), median(P(:, 4)), min(P(:, 4)), max(P(:, 4)), sum(P(:, 4) > 0), median(P(:, 5)), min(P(:, 5)), max(P(:, 5)));
nsl = 0; nfa = 0; nti = 0;
for fz = 0:1, for nc = 0:1, for a = [0.25 1]
  h0 = zeros(1, 8); h1 = h0;
  for s = 1:8
    h0(s) = X(X(:, 1) == nc & X(:, 2) == 0 & X(:, 3) == a & X(:, 4) == fz & X(:, 5) == s, 6);
    h1(s) = X(X(:, 1) == nc & X(:, 2) == 1 & X(:, 3) == a & X(:, 4) == fz & X(:, 5) == s, 6);
  end
  nsl = nsl + sum(h1 > h0); nfa = nfa + sum(h1 < h0); nti = nti + sum(h1 == h0);
  printf('frozen=%d new=%d a=%.2f: median reversed %g, kept %g; kept slower %d, faster %d, tie %d\n', fz, nc, a, median(h0), median(h1), sum(h1 > h0), sum(h1 < h0), sum(h1 == h0));
end, end, end
printf('all paired comparisons: kept slower %d, faster %d, tie %d (of %d)\n', nsl, nfa, nti, nsl + nfa + nti);
d = dir(fullfile(od, 'run_*.mat')); Lr = [];
for i = 1:numel(d), o = load(fullfile(d(i).folder, d(i).name)); o = o.o; Lr(end + 1, :) = [o.new_code o.kept o.amp o.frozen o.lam0]; end %#ok<AGROW>
for a = [0.25 1], q = Lr(:, 1) == 1 & Lr(:, 2) == 0 & Lr(:, 3) == a & Lr(:, 4) == 0; printf('lambda at restoration, prosthetic code, scaling reversed, a=%.2f: median %.3f\n', a, median(Lr(q, 5))); end
% slow-down versus theta, prosthetic code, trainable inputs, geometric mean over strengths
th = zeros(8, 1); gm = th;
for s = 1:8
  r = []; for a = [0.25 1]
    h0 = X(X(:, 1) == 1 & X(:, 2) == 0 & X(:, 3) == a & X(:, 4) == 0 & X(:, 5) == s, 6);
    h1 = X(X(:, 1) == 1 & X(:, 2) == 1 & X(:, 3) == a & X(:, 4) == 0 & X(:, 5) == s, 6); r(end + 1) = h1 / h0; %#ok<AGROW>
  end
  th(s) = P(s, 5); gm(s) = exp(mean(log(r)));
end
set_seed(5); bg = zeros(1, 2000); for b = 1:2000, bg(b) = exp(mean(log(gm(randi(8, 1, 8))))); end; bg = sort(bg);
printf('prosthetic slow-down geo-mean %.2f, 95%% CI over networks %.2f to %.2f\n', exp(mean(log(gm))), bg(51), bg(1950));
matched_error(od);
rn = corr(tiedrank_(th), tiedrank_(gm)); set_seed(4); bs = zeros(1, 2000);
for b = 1:2000, i = randi(8, 1, 8); bs(b) = corr(tiedrank_(th(i)), tiedrank_(gm(i))); end
nd = sum(~isfinite(bs)); bs = sort(bs(isfinite(bs))); nb = numel(bs);
printf('prosthetic code: per-network slow-down %s (theta %s); geo-mean %.2f; Spearman %.2f (95%% CI %.2f to %.2f; %d undefined resamples)\n', ...
  sprintf('%.2f ', gm), sprintf('%.2f ', th), exp(mean(log(gm))), rn, bs(max(1, round(0.025 * nb))), bs(round(0.975 * nb)), nd);
end

function stats_diagnostics()
here = fileparts(mfilename('fullpath')); d = dir(fullfile(here, '..', 'results', 'expG', 'run_*.mat')); A = [];
for i = 1:numel(d)
  o = load(fullfile(d(i).folder, d(i).name)); o = o.o; h = o.it_hit; if isnan(h), h = Inf; end
  m = min(200, o.iters_run);
  A(end + 1, :) = [o.g o.k o.seed h o.lam_t(1) o.lam_t(end) mean(o.gnorm(1:m) > 1) o.indep_hit]; %#ok<AGROW>
end
printf('\n=== Training diagnostics (Experiment G) ===\n');
for k = [10 20]
  s = A(:, 2) == k & isfinite(A(:, 4)); le = A(s, 6); tgt = median(le);
  printf('k=%d: %d learners; lambda after training median %.3f (IQR %.3f to %.3f)\n', k, sum(s), tgt, prc(le, 25), prc(le, 75));
  for g = [0.5 1.6], q = s & abs(A(:, 1) - g) < 1e-9; printf('   g=%.1f: lambda %.3f -> %.3f\n', g, median(A(q, 5)), median(A(q, 6))); end
  sds = arrayfun(@(sd) std(A(s & A(:, 3) == sd, 6)), 1:8); sd0 = arrayfun(@(sd) std(A(s & A(:, 3) == sd, 5)), 1:8);
  printf('   within-network s.d. across gains: before %.3f, after %.3f\n', median(sd0), median(sds));
  printf('   Spearman(iterations, |lambda0 - trained|) = %.2f; (iterations, |lambda0|) = %.2f\n', ...
    corr(tiedrank_(A(s, 4)), tiedrank_(abs(A(s, 5) - tgt))), corr(tiedrank_(A(s, 4)), tiedrank_(abs(A(s, 5)))));
  % leave-one-network-out target: trained exponent of the other seven networks
  r = find(s); dl = zeros(numel(r), 1);
  for q = 1:numel(r), o = s & A(:, 3) ~= A(r(q), 3); dl(q) = abs(A(r(q), 5) - median(A(o, 6))); end
  loo = corr(tiedrank_(A(s, 4)), tiedrank_(dl));
  set_seed(6); bs = zeros(1, 2000); sd = A(s, 3);
  for b = 1:2000, ii = randi(8, 1, 8); idx = cell2mat(arrayfun(@(x) find(sd == x), ii, 'UniformOutput', false)'); bs(b) = corr(tiedrank_(A(r(idx), 4)), tiedrank_(dl(idx))); end
  bs = sort(bs); printf('   leave-one-network-out: Spearman %.2f (95%% CI over networks %.2f to %.2f)\n', loo, bs(51), bs(1950));
  % maximal clipped fraction among runs with g <= 1.6
  q = A(:, 2) == k & A(:, 1) <= 1.6 + 1e-9; printf('   g<=1.6: max clipped fraction (first 200) %.3f\n', max(A(q, 7)));
  for g = unique(A(:, 1))', q = A(:, 2) == k & abs(A(:, 1) - g) < 1e-9; c(g == unique(A(:, 1))') = median(A(q, 7)); end %#ok<AGROW>
  printf('   clipped fraction (first 200 its), median per gain: %s\n', sprintf('%.2f ', c));
end
ok = isfinite(A(:, 8)); printf('independent test NMSE when the criterion was first met: median %.3f, max %.3f, below 0.1 in %d of %d\n', median(A(ok, 8)), max(A(ok, 8)), sum(A(ok, 8) < 0.1), sum(ok));
end

function stats_feasibility()
here = fileparts(mfilename('fullpath')); F = load(fullfile(here, '..', 'results', 'expA2_feasibility.mat')); F = F.R;
printf('\n=== Readout feasibility (Experiment A2) ===\n');
for j = 1:3
  m = median(F.opt(:, :, j), 2)'; [mn, i] = min(m);
  printf('k=%d: best achievable NMSE min %.2f at g=%.1f; below 0.2 for g in %s\n', F.kl(j), mn, F.gs(i), sprintf('%.1f ', F.gs(m < 0.2)));
  t = median(F.trel(:, :, j), 2)'; ok = isfinite(t);
  if any(ok), [tm, it] = min(t); printf('   samples to 90%% of own optimum: fastest %g at g=%s; finite for g %.1f-%.1f; at g=1.3 %g, 1.4 %g\n', tm, sprintf('%.1f ', F.gs(t == tm)), min(F.gs(ok)), max(F.gs(ok)), t(abs(F.gs - 1.3) < 1e-9), t(abs(F.gs - 1.4) < 1e-9)); end
end
end

function matched_error(od)
% initial errors before retraining, and relearning time from a matched error: for the
% kept network, iterations from the first time its error falls to the reversed
% network's initial error until the criterion, compared with the reversed network
d = dir(fullfile(od, 'run_*.mat')); R = {};
for i = 1:numel(d), o = load(fullfile(d(i).folder, d(i).name)); R{end + 1} = o.o; end %#ok<AGROW>
key = @(o) [o.new_code o.kept o.amp o.frozen o.seed];
K = cell2mat(cellfun(key, R, 'UniformOutput', false)');
for nc = 0:1, for a = [0.25 1]
  if nc == 0 && a == 1, continue; end
  e0 = []; e1 = []; t0 = []; t1m = []; t1 = [];
  for s = 1:8
    i0 = find(K(:, 1) == nc & K(:, 2) == 0 & K(:, 3) == a & K(:, 4) == 0 & K(:, 5) == s);
    i1 = find(K(:, 1) == nc & K(:, 2) == 1 & K(:, 3) == a & K(:, 4) == 0 & K(:, 5) == s);
    o0 = R{i0}; o1 = R{i1}; e0(s) = o0.err_init; e1(s) = o1.err_init; t0(s) = o0.it_hit; t1(s) = o1.it_hit;
    c = o1.curve; it = find(isfinite(c) & c <= o0.err_init, 1);
    if o1.err_init <= o0.err_init, it = 0; end
    t1m(s) = o1.it_hit - it;
  end
  printf('new=%d a=%.2f: NMSE before retraining reversed %.2f kept %.2f (kept larger in %d/8); time reversed %g, kept %g, kept from matched error %g (kept-from-match slower in %d, faster in %d, tie %d)\n', ...
    nc, a, median(e0), median(e1), sum(e1 > e0), median(t0), median(t1), median(t1m), sum(t1m > t0), sum(t1m < t0), sum(t1m == t0));
end, end
end
