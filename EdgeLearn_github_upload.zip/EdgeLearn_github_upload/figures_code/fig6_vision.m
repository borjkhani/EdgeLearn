function fig6_vision()
%FIG6_VISION  Relearning after deprivation in networks that had learned the task
%   (Experiment F2; 64-unit networks, 8 per condition, delay 10).
%   a  Lyapunov exponent of each trained network: healthy (natural input),
%      deprived (input amplitude 0.25), deprived after homeostatic scaling
%   b  iterations to relearn with the same input code after restoration at 25%
%      or full strength, with the scaling reversed or kept (lines: same network;
%      0: criterion already met; log axis of iterations + 1)
%   c  the same with a new (prosthetic) input code
%   d  slow-down with scaling kept (prosthetic code) versus the network's scaling
%      factor; filled: input weights trainable, open: frozen
here = fileparts(mfilename('fullpath')); addpath(fullfile(here, '..', 'src'));
S = fig_style(); fh = figure('Visible', 'off', 'Color', 'w');
od = fullfile(here, '..', 'results', 'expF2'); d = dir(fullfile(od, 'run_*.mat')); X = [];
for i = 1:numel(d)
  o = load(fullfile(d(i).folder, d(i).name)); o = o.o; h = o.it_hit; if isnan(h), h = Inf; end
  X(end + 1, :) = [o.new_code o.kept o.amp o.frozen o.seed h o.theta]; %#ok<AGROW>
end
L = nan(3, 8);
for s = 1:8, P = load(fullfile(od, sprintf('pretrained_%d.mat', s))); L(:, s) = [P.Pt.lam_trained; P.Pt.lam_depr0; P.Pt.lam_depr]; end
% a
ax = subplot(2, 2, 1); hold(ax, 'on'); cc = [S.col(1, :); 0.55 0.55 0.55; 0.70 0.12 0.12];
for s = 1:8, plot(ax, 1:3, L(:, s), '-', 'Color', [0.8 0.8 0.8], 'LineWidth', 0.8); end
for j = 1:3
  plot(ax, j * ones(1, 8), L(j, :), 'o', 'Color', cc(j, :), 'MarkerFaceColor', cc(j, :), 'MarkerSize', S.ms);
  plot(ax, j + [-0.18 0.18], median(L(j, :)) * [1 1], '-', 'Color', S.ink, 'LineWidth', 2);
end
line(ax, [0.5 3.5], [0 0], 'Color', S.ink2, 'LineStyle', '--'); text(ax, 3.12, 0.035, 'edge', 'Color', S.ink2, 'FontSize', S.fs - 1);
set(ax, 'XTick', 1:3, 'XTickLabel', {'trained', 'deprived', '+ scaling'});
xlim(ax, [0.5 3.5]); ylim(ax, [-0.36 0.08]); ylabel(ax, '\lambda (per step)');
style_axes(ax, 'a  deprivation and scaling: towards the edge');
% b, c: paired relearning times (input weights trainable)
tl = {'b  same input code', 'c  new (prosthetic) code'};
for p = 1:2
  ax = subplot(2, 2, p + 1); hold(ax, 'on'); xs = [1 2; 4 5]; amps = [0.25 1];
  for q = 1:2
    for s = 1:8
      h0 = X(X(:, 1) == p - 1 & X(:, 2) == 0 & X(:, 3) == amps(q) & X(:, 4) == 0 & X(:, 5) == s, 6);
      h1 = X(X(:, 1) == p - 1 & X(:, 2) == 1 & X(:, 3) == amps(q) & X(:, 4) == 0 & X(:, 5) == s, 6);
      plot(ax, xs(q, :), [h0 h1] + 1, '-', 'Color', [0.78 0.78 0.78], 'LineWidth', 0.8);
      plot(ax, xs(q, 1), h0 + 1, 'o', 'Color', S.col(1, :), 'MarkerFaceColor', S.col(1, :), 'MarkerSize', S.ms - 1);
      plot(ax, xs(q, 2), h1 + 1, 's', 'Color', [0.70 0.12 0.12], 'MarkerFaceColor', [0.70 0.12 0.12], 'MarkerSize', S.ms - 1);
    end
  end
  set(ax, 'YScale', 'log', 'XTick', [1 2 4 5], 'XTickLabel', {'rev.', 'kept', 'rev.', 'kept'}, ...
      'YTick', [1 3 11 31 101], 'YTickLabel', {'0', '2', '10', '30', '100'});
  text(ax, 1.5, 230, 'strength 25%', 'HorizontalAlignment', 'center', 'FontSize', S.fs - 1, 'Color', S.ink2);
  text(ax, 4.5, 230, 'full strength', 'HorizontalAlignment', 'center', 'FontSize', S.fs - 1, 'Color', S.ink2);
  xlim(ax, [0.4 5.6]); ylim(ax, [0.8 330]); ylabel(ax, 'iterations to relearn');
  style_axes(ax, tl{p});
end
% d
ax = subplot(2, 2, 4); hold(ax, 'on'); mk = {'o', 's'}; col = [0.5 0.5 0.5; S.col(2, :)];
for fz = 0:1
  for q = [0.25 1]
    for s = 1:8
      h0 = X(X(:, 1) == 1 & X(:, 2) == 0 & X(:, 3) == q & X(:, 4) == fz & X(:, 5) == s, 6);
      h1 = X(X(:, 1) == 1 & X(:, 2) == 1 & X(:, 3) == q & X(:, 4) == fz & X(:, 5) == s, 6);
      th = X(X(:, 5) == s, 7); th = th(1); ci = 1 + (q == 1); mf = col(ci, :); if fz, mf = 'w'; end
      plot(ax, th + 0.004 * (fz - 0.5), h1 / h0, mk{ci}, 'Color', col(ci, :), 'MarkerFaceColor', mf, 'MarkerSize', S.ms - 1);
    end
  end
end
line(ax, [1.05 1.45], [1 1], 'Color', S.ink2, 'LineStyle', '--');
set(ax, 'YScale', 'log', 'YTick', [1 2 3 5], 'YTickLabel', {'1', '2', '3', '5'}); ylim(ax, [0.6 7]); xlim(ax, [1.05 1.45]);
text(ax, 1.15, 0.86, 'circles: 25% strength, squares: full', 'FontSize', S.fs - 2, 'Color', S.ink2);
text(ax, 1.15, 0.72, 'open: input weights frozen', 'FontSize', S.fs - 2, 'Color', S.ink2);
xlabel(ax, 'homeostatic scaling factor \theta'); ylabel(ax, 'relearning time, kept / reversed');
style_axes(ax, 'd  slow-down versus scaling');
save_fig(fh, 'Fig6_vision', 17, 12); close(fh);
end
