function fig4_readout()
%FIG4_READOUT  Learning only the readout of a fixed network (Experiment A; 200
%   units, 10 networks per gain).
%   a  memory profile: squared correlation between the input k steps back and its
%      best linear reconstruction (ridge readout), mean over networks
%      (triangle: gain with the largest total memory capacity)
%   b  best achievable test NMSE of a linear readout (Experiment A2; median)
%   c  samples the online rule needs to achieve 90% of each network's own
%      achievable improvement (median and interquartile range)
%   d  samples to reach test NMSE < 0.2 (x: not reached within 19 940 samples)
%   e  total memory capacity and effective dimensionality (participation ratio of
%      the state covariance), each relative to its maximum
here = fileparts(mfilename('fullpath')); S = fig_style(); fh = figure('Visible', 'off', 'Color', 'w');
load(fullfile(here, '..', 'results', 'expA_reservoir.mat'), 'R');
lam = mean(R.lam_cond, 2)'; g0 = interp1(lam, R.gs, 0);       % driven edge
ax = subplot(2, 3, [1 4]); hold(ax, 'on');
M = squeeze(mean(R.MCk, 2))'; kk = R.ks <= 40;
imagesc(ax, R.gs, R.ks(kk), M(kk, :)); set(ax, 'YDir', 'normal', 'CLim', [0 1]);
colormap(ax, interp1([0 0.5 1], [1 1 1; 0.45 0.62 0.85; 0.08 0.18 0.45], linspace(0, 1, 64)));
line(ax, g0 * [1 1], [0.5 40.5], 'Color', [0.7 0.12 0.12], 'LineWidth', 1.6, 'LineStyle', '--');
text(ax, g0 + 0.05, 37, 'edge (\lambda = 0)', 'Color', [0.7 0.12 0.12], 'FontSize', S.fs - 1);
[~, im] = max(sum(M, 1)); plot(ax, R.gs(im), 2, 'v', 'Color', S.ink, 'MarkerFaceColor', S.ink, 'MarkerSize', S.ms + 1);
xlim(ax, [R.gs(1) - 0.05, R.gs(end) + 0.05]); ylim(ax, [0.5 40.5]);
xlabel(ax, 'gain g'); ylabel(ax, 'how far back (steps)'); colorbar(ax);
style_axes(ax, 'a  what a linear readout can recall'); grid(ax, 'off');
% b: best achievable error; c: samples to reach 90% of each network's own achievable improvement
F2 = load(fullfile(here, '..', 'results', 'expA2_feasibility.mat')); F2 = F2.R; kc3 = [0.10 0.27 0.55; 0.106 0.60 0.42; 0.93 0.55 0.10];
ax = subplot(2, 3, 2); hold(ax, 'on'); hl = [];
for j = 1:3
  m = median(F2.opt(:, :, j), 2)';
  hl(j) = plot(ax, F2.gs, m, ['-' S.mk{j}], 'Color', kc3(j, :), 'MarkerFaceColor', kc3(j, :), 'MarkerSize', S.ms - 2, 'LineWidth', S.lw); %#ok<AGROW>
end
line(ax, [0.2 2.6], [0.2 0.2], 'Color', S.ink2, 'LineStyle', ':');
line(ax, g0 * [1 1], [0 1.05], 'Color', [0.7 0.12 0.12], 'LineStyle', '--', 'LineWidth', 1.2);
xlim(ax, [0.2 2.8]); ylim(ax, [0 1.05]); xlabel(ax, 'gain g'); ylabel(ax, 'best achievable NMSE');
for j = 1:3, m = median(F2.opt(:, :, j), 2)'; text(ax, 2.55, m(end), sprintf(' %d', F2.kl(j)), 'Color', kc3(j, :), 'FontSize', S.fs - 2); end
text(ax, 1.55, 0.12, 'labels: delay', 'FontSize', S.fs - 3, 'Color', S.ink2);
style_axes(ax, 'b  what can be reached');
ax = subplot(2, 3, 3); hold(ax, 'on'); hl = [];
for j = 1:2
  T = squeeze(F2.trel(:, :, j)); md = median(T, 2)'; ok = isfinite(md);
  q1 = prctile_inf(T, 25); q3 = prctile_inf(T, 75);
  for i = find(ok), line(ax, F2.gs(i) * [1 1], [q1(i) min(q3(i), 3e4)], 'Color', 0.5 * kc3(j, :) + 0.5, 'LineWidth', 1.1); end
  hl(j) = plot(ax, F2.gs(ok), md(ok), ['-' S.mk{j}], 'Color', kc3(j, :), 'MarkerFaceColor', kc3(j, :), 'MarkerSize', S.ms - 2, 'LineWidth', S.lw); %#ok<AGROW>
end
line(ax, g0 * [1 1], [50 5e4], 'Color', [0.7 0.12 0.12], 'LineStyle', '--', 'LineWidth', 1.2);
set(ax, 'YScale', 'log'); ylim(ax, [50 3e4]); xlim(ax, [0.2 2.6]); xlabel(ax, 'gain g'); ylabel(ax, 'samples to own optimum');
legend(ax, hl, {'delay 5', 'delay 10'}, 'Location', 'north', 'Box', 'off', 'FontSize', S.fs - 3);
style_axes(ax, 'c  how fast it is reached');
% d: learning time to a fixed criterion
ax = subplot(2, 3, 5); hold(ax, 'on'); kc = [0.10 0.27 0.55; 0.106 0.60 0.42]; hl = [];
for j = 1:2
  T = squeeze(R.tlearn(:, :, j)); md = median(T, 2)'; q1 = prctile_inf(T, 25); q3 = prctile_inf(T, 75);
  ok = isfinite(md);
  for i = find(ok), line(ax, R.gs(i) * [1 1], [q1(i) min(q3(i), 3e4)], 'Color', 0.5 * kc(j, :) + 0.5, 'LineWidth', 1.2); end
  hl(j) = plot(ax, R.gs(ok), md(ok), ['-' S.mk{j}], 'Color', kc(j, :), 'MarkerFaceColor', kc(j, :), 'MarkerSize', S.ms - 1, 'LineWidth', S.lw); %#ok<AGROW>
  plot(ax, R.gs(~ok), 3.2e4 * (1 + 0.3 * (j - 1)) * ones(1, sum(~ok)), 'x', 'Color', kc(j, :), 'MarkerSize', S.ms - 1, 'LineWidth', 1);
end
line(ax, g0 * [1 1], [50 5e4], 'Color', [0.7 0.12 0.12], 'LineStyle', '--', 'LineWidth', 1.2);
set(ax, 'YScale', 'log'); ylim(ax, [50 5e4]); xlim(ax, [0.2 2.6]);
xlabel(ax, 'gain g'); ylabel(ax, 'samples to learn');
legend(ax, hl, {'delay 5', 'delay 10'}, 'Location', 'southeast', 'Box', 'off', 'FontSize', S.fs - 2);

style_axes(ax, 'd  fixed criterion (NMSE < 0.2)');
% c: dimensionality versus memory, both relative to their maximum
ax = subplot(2, 3, 6); hold(ax, 'on');
pr = mean(R.PR, 2)'; mc = mean(sum(R.MCk, 3), 2)';
h1 = plot(ax, R.gs, pr / max(pr), '-o', 'Color', S.col(2, :), 'MarkerFaceColor', S.col(2, :), 'MarkerSize', S.ms - 1, 'LineWidth', S.lw);
h2 = plot(ax, R.gs, mc / max(mc), '-s', 'Color', S.col(1, :), 'MarkerFaceColor', S.col(1, :), 'MarkerSize', S.ms - 1, 'LineWidth', S.lw);
line(ax, g0 * [1 1], [0 1.05], 'Color', [0.7 0.12 0.12], 'LineStyle', '--', 'LineWidth', 1.2);
xlim(ax, [0.2 2.6]); ylim(ax, [0 1.05]); xlabel(ax, 'gain g'); ylabel(ax, 'relative to maximum');
text(ax, 0.3, 0.93, 'memory capacity', 'Color', S.col(1, :), 'FontSize', S.fs - 1);
text(ax, 1.9, 0.45, 'dimensionality', 'Color', S.col(2, :), 'FontSize', S.fs - 1);
style_axes(ax, 'e  richer is not better');
save_fig(fh, 'Fig4_readout', 18 + 2 * ~isempty(getenv('NECO_FIGS')), 11.5 + 2 * ~isempty(getenv('NECO_FIGS'))); close(fh);
end

function p = prctile_inf(T, q)
p = nan(1, size(T, 1));
for i = 1:size(T, 1)
  x = sort(T(i, :)); n = numel(x); r = 1 + (n - 1) * q / 100; lo = floor(r); hi = ceil(r);
  if isinf(x(hi)), p(i) = Inf; else, p(i) = x(lo) + (r - lo) * (x(hi) - x(lo)); end
end
end
