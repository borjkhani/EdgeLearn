function D = load_runs(name)
%LOAD_RUNS  Collect the per-run files of a training experiment into arrays.
%   D.g, D.k, D.seed, D.hit (Inf if the criterion was never reached), D.final,
%   D.lam0, D.cond (Experiment D only), D.curve (cell).
d = dir(fullfile(fileparts(mfilename('fullpath')), '..', 'results', name, 'run_*.mat'));
n = numel(d); D.g = nan(n, 1); D.k = D.g; D.seed = D.g; D.hit = D.g; D.final = D.g; D.lam0 = D.g;
D.cond = cell(n, 1); D.curve = cell(n, 1); D.k2 = cell(n, 1);
for i = 1:n
  S = load(fullfile(d(i).folder, d(i).name)); o = S.o;
  D.g(i) = o.g; D.seed(i) = o.seed; D.final(i) = o.final; D.curve{i} = o.curve;
  h = o.it_hit; if isnan(h), h = Inf; end, D.hit(i) = h;
  if isfield(o, 'k'), D.k(i) = o.k(1); end
  if isfield(o, 'lam0'), D.lam0(i) = o.lam0; end
  if isfield(o, 'cond'), D.cond{i} = o.cond; end
end
end
