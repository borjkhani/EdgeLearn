function Q = sweet_spot(D, k)
%SWEET_SPOT  Per-seed fastest-learning gain and its Lyapunov exponent for delay k.
%   For each seed, the gain(s) with the fewest iterations to criterion are found
%   (ties are averaged; networks that never learned are left out). Returns per-seed g* and lambda*, the per-gain medians,
%   interquartile ranges and the number of seeds that reached the criterion.
s = D.k == k; gs = unique(D.g(s))'; seeds = unique(D.seed(s))';
Q.gs = gs; Q.med = nan(size(gs)); Q.q25 = Q.med; Q.q75 = Q.med; Q.nsolved = Q.med; Q.lam = Q.med;
for j = 1:numel(gs)
  h = D.hit(s & D.g == gs(j)); Q.nsolved(j) = sum(isfinite(h)); Q.n = numel(h);
  Q.med(j) = median(h); Q.q25(j) = prctile_(h, 25); Q.q75(j) = prctile_(h, 75);
  Q.lam(j) = mean(D.lam0(s & D.g == gs(j)));
end
Q.gstar = nan(size(seeds)); Q.lamstar = Q.gstar;
for i = 1:numel(seeds)
  r = s & D.seed == seeds(i); h = D.hit(r); g = D.g(r); l = D.lam0(r);
  if ~any(isfinite(h)), continue; end          % this network never learned the task
  b = h == min(h); Q.gstar(i) = mean(g(b)); Q.lamstar(i) = mean(l(b));
end
end

function p = prctile_(x, q)
% percentile with Inf allowed (linear interpolation on sorted values)
x = sort(x(:)); n = numel(x); r = 1 + (n - 1) * q / 100; lo = floor(r); hi = ceil(r);
if isinf(x(hi)) || isinf(x(lo)), p = x(hi); else, p = x(lo) + (r - lo) * (x(hi) - x(lo)); end
end
