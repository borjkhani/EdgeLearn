function save_fig(fh, name, w_cm, h_cm)
%SAVE_FIG  Export figure fh to ../figures/<name>.pdf and .png (300 dpi).
if nargin < 3, w_cm = 17; end
if nargin < 4, h_cm = 12; end
outdir = fullfile(fileparts(mfilename('fullpath')), '..', 'figures');
neco = ~isempty(getenv('NECO_FIGS'));   % Neural Computation: larger relative text
if neco, outdir = fullfile(fileparts(mfilename('fullpath')), '..', 'figures_neco'); end
if ~exist(outdir, 'dir'), mkdir(outdir); end
k = 1.35;  % render on a larger page; 11-pt text then prints at about 8 pt at 17 cm width
if neco, k = 1.15; h_cm = 1.12 * h_cm; end   % text about 8 pt at the 14.6-cm NECO text width
set(fh, 'PaperUnits', 'centimeters', 'PaperSize', k * [w_cm h_cm], ...
        'PaperPosition', [0 0 k * w_cm k * h_cm]);
print(fh, '-dpdf', fullfile(outdir, [name '.pdf']));
print(fh, '-dpng', '-r300', fullfile(outdir, [name '.png']));
end
