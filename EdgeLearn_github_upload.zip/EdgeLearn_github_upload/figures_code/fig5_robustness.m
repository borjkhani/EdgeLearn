function fig5_robustness()
%FIG5_ROBUSTNESS  Does the sweet spot depend on network size, learning rate or task?
%   Iterations to criterion (median and interquartile range over 5 networks;
%   x: not learned by the majority) versus the initial gain (a, c) and versus the
%   initial Lyapunov exponent (b, d).
%   a, b  delay 10, networks of 32, 64 and 128 units (64: Experiment B)
%   c, d  delay 10 with learning rates 1e-3, 3e-3 (Experiment B), 1e-2, and the
%         nonlinear product task u(t-5) u(t-10) (criterion NMSE < 0.2)
here = fileparts(mfilename('fullpath')); addpath(fullfile(here, '..', 'src'));
S = fig_style(); fh = figure('Visible', 'off', 'Color', 'w');
Dd = load_runs('expD'); B = load_runs('expB');
% Lyapunov exponents of the initial networks (recomputed where not stored)
for i = find(isnan(Dd.lam0))'
  n = cond_N(Dd.cond{i}); set_seed(Dd.seed(i)); W = Dd.g(i) * randn(n) / sqrt(n); win = randn(n, 1);
  Dd.lam0(i) = lyap_rnn(W, win, Dd.seed(i));
end
Bk = B.k == 10 & B.seed <= 5;
sets = {{'N32', 'N = 32'}, {'B', 'N = 64'}, {'N128', 'N = 128'}; ...
        {'lr1e-3', 'lr 10^{-3}'}, {'B', '3\times10^{-3}'}, {'lr1e-2', '10^{-2}'}};
cc = [0.10 0.27 0.55; 0.106 0.60 0.42; 0.93 0.55 0.10; 0.70 0.12 0.12];
for row = 1:2
  for p = 1:2
    ax = subplot(2, 2, 2 * (row - 1) + p); hold(ax, 'on'); hl = []; lb = {};
    items = sets(row, :); if row == 2, items{end + 1} = {'product', 'product'}; end %#ok<AGROW>
    for j = 1:numel(items)
      nm = items{j}{1};
      if strcmp(nm, 'B'), r = Bk; G = B.g; H = B.hit; L = B.lam0;
      else, r = strcmp(Dd.cond, nm); G = Dd.g; H = Dd.hit; L = Dd.lam0; end
      gs = unique(G(r))'; md = nan(size(gs)); q1 = md; q3 = md; lx = md; ok = false(size(gs));
      for i = 1:numel(gs)
        h = sort(H(r & G == gs(i))); n = numel(h); md(i) = median(h); ok(i) = sum(isfinite(h)) > n / 2;
        q1(i) = h(max(1, round(0.25 * n + 0.5))); q3(i) = h(min(n, round(0.75 * n + 0.5)));
        lx(i) = mean(L(r & G == gs(i)));
      end
      x = gs; if p == 2, x = lx; end
      for i = find(ok), line(ax, x(i) * [1 1], [q1(i) min(q3(i), 6000)], 'Color', 0.5 * cc(j, :) + 0.5, 'LineWidth', 1.1); end
      hl(end + 1) = plot(ax, x(ok), md(ok), ['-' S.mk{j}], 'Color', cc(j, :), 'MarkerFaceColor', cc(j, :), 'MarkerSize', S.ms - 1, 'LineWidth', S.lw); %#ok<AGROW>
      plot(ax, x(~ok), 6000 * (1 + 0.35 * (j - 1)) * ones(1, sum(~ok)), 'x', 'Color', cc(j, :), 'MarkerSize', S.ms, 'LineWidth', 1.2);
      lb{end + 1} = items{j}{2}; %#ok<AGROW>
    end
    set(ax, 'YScale', 'log'); ylim(ax, [10 2e4]); ylabel(ax, 'iterations to learn');
    if p == 1, xlim(ax, [0.2 2.6]); xlabel(ax, 'initial gain g');
    else, xlim(ax, [-1.5 0.3]); xlabel(ax, 'initial \lambda (per step)'); line(ax, [0 0], [10 2e4], 'Color', S.ink2, 'LineStyle', '--'); end
    legend(ax, hl, lb, 'Location', 'south', 'Orientation', 'horizontal', 'Box', 'off', 'FontSize', S.fs - 3);
    t = {'a  network size', 'b  network size, versus \lambda', 'c  learning rate and task', 'd  learning rate and task, versus \lambda'};
    style_axes(ax, t{2 * (row - 1) + p});
  end
end
save_fig(fh, 'Fig5_robustness', 17, 12); close(fh);
end

function n = cond_N(c)
n = 64; if strcmp(c, 'N32'), n = 32; elseif strcmp(c, 'N128'), n = 128; end
end
