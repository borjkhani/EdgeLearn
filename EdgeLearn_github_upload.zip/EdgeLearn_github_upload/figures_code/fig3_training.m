function fig3_training()
%FIG3_TRAINING  What whole-network training does to the dynamics (Experiment G:
%   the runs of Experiment B for delays 10 and 20, repeated with diagnostics).
%   a  Lyapunov exponent during training, delay 20: median over the networks still
%      training; the line ends (x) when more than half of the networks had stopped
%   b  exponent after versus before training (filled: learned; open: not learned)
%   c  iterations to learn versus the distance between the initial exponent and the
%      median exponent of the trained networks for that delay
%   d  fraction of the first 200 iterations in which the gradient was clipped
here = fileparts(mfilename('fullpath')); S = fig_style(); fh = figure('Visible', 'off', 'Color', 'w');
d = dir(fullfile(here, '..', 'results', 'expG', 'run_*.mat')); n = numel(d);
g = nan(n, 1); k = g; hit = g; l0 = g; l1 = g; clip = g; ir = g; LT = cell(n, 1); IT = LT;
for i = 1:n
  o = load(fullfile(d(i).folder, d(i).name)); o = o.o;
  g(i) = o.g; k(i) = o.k; hit(i) = o.it_hit; if isnan(hit(i)), hit(i) = Inf; end
  l0(i) = o.lam_t(1); l1(i) = o.lam_t(end); LT{i} = o.lam_t; IT{i} = o.lam_it; ir(i) = o.iters_run;
  m = min(200, o.iters_run); clip(i) = mean(o.gnorm(1:m) > 1);
end
kc = [0.106 0.60 0.42; 0.93 0.55 0.10];
% a
ax = subplot(2, 2, 1); hold(ax, 'on'); gsel = [0.5 0.8 1.2 1.6 2.0]; cm = gain_cmap(numel(gsel)); hl = [];
for j = 1:numel(gsel)
  r = find(k == 20 & abs(g - gsel(j)) < 1e-9); its = [1 250:250:3000]; M = nan(numel(r), numel(its));
  for q = 1:numel(r)
    lt = LT{r(q)}; ii = IT{r(q)}; [tf, loc] = ismember(its, ii); M(q, tf) = lt(loc(tf));   % NaN after the run stopped
  end
  act = sum(isfinite(M), 1); md = nan(1, numel(its));
  for c = 1:numel(its), if act(c) >= numel(r) / 2, md(c) = median(M(isfinite(M(:, c)), c)); end, end
  ok = isfinite(md); last = find(ok, 1, 'last');
  hl(j) = plot(ax, its(ok), md(ok), '-o', 'Color', cm(j, :), 'MarkerFaceColor', cm(j, :), 'MarkerSize', S.ms - 2, 'LineWidth', S.lw); %#ok<AGROW>
  if last < numel(its), plot(ax, its(last), md(last), 'x', 'Color', cm(j, :), 'MarkerSize', S.ms + 3, 'LineWidth', 1.6); end
end
line(ax, [0 3000], [0 0], 'Color', S.ink2, 'LineStyle', '--');
xlim(ax, [0 3000]); ylim(ax, [-0.9 0.15]); xlabel(ax, 'training iteration'); ylabel(ax, '\lambda (per step)');
legend(ax, hl, arrayfun(@(x) sprintf('g = %.1f', x), gsel, 'UniformOutput', false), 'Location', 'southeast', 'Box', 'off', 'FontSize', S.fs - 2);
style_axes(ax, 'a  exponent during training');
% b
ax = subplot(2, 2, 2); hold(ax, 'on'); hl = [];
for p = 1:2
  kk = [10 20]; r = k == kk(p); ok = r & isfinite(hit); no = r & ~isfinite(hit);
  hl(p) = plot(ax, l0(ok), l1(ok), S.mk{p + 1}, 'Color', kc(p, :), 'MarkerFaceColor', kc(p, :), 'MarkerSize', S.ms - 1); %#ok<AGROW>
  plot(ax, l0(no), l1(no), S.mk{p + 1}, 'Color', kc(p, :), 'MarkerFaceColor', 'w', 'MarkerSize', S.ms - 1);
end
line(ax, [-1.5 0.3], [-1.5 0.3], 'Color', S.ink2, 'LineStyle', ':'); line(ax, [-1.5 0.3], [0 0], 'Color', S.ink2, 'LineStyle', '--');
xlim(ax, [-1.5 0.3]); ylim(ax, [-1.25 0.15]); xlabel(ax, '\lambda before training'); ylabel(ax, '\lambda after training');
legend(ax, hl, {'delay 10', 'delay 20'}, 'Location', 'south', 'Box', 'off', 'FontSize', S.fs - 2);
style_axes(ax, 'b  before versus after');
% c
ax = subplot(2, 2, 3); hold(ax, 'on'); hl = [];
for p = 1:2
  kk = [10 20]; r = k == kk(p) & isfinite(hit); tgt = median(l1(r));
  hl(p) = plot(ax, abs(l0(r) - tgt), hit(r), S.mk{p + 1}, 'Color', kc(p, :), 'MarkerFaceColor', kc(p, :), 'MarkerSize', S.ms - 1); %#ok<AGROW>
end
set(ax, 'YScale', 'log', 'YTick', [30 100 300 1000 3000], 'YTickLabel', {'30', '100', '300', '1000', '3000'});
xlim(ax, [0 1.3]); ylim(ax, [20 3500]);
xlabel(ax, '|\lambda before - \lambda of trained networks|'); ylabel(ax, 'iterations to learn');
legend(ax, hl, {'delay 10', 'delay 20'}, 'Location', 'southeast', 'Box', 'off', 'FontSize', S.fs - 2);
style_axes(ax, 'c  starting close to the target is fastest');
% d
ax = subplot(2, 2, 4); hold(ax, 'on'); gs = unique(g)'; hl = [];
for p = 1:2
  kk = [10 20]; md = arrayfun(@(x) median(clip(k == kk(p) & g == x)), gs);
  hl(p) = plot(ax, gs, md, ['-' S.mk{p + 1}], 'Color', kc(p, :), 'MarkerFaceColor', kc(p, :), 'MarkerSize', S.ms - 1, 'LineWidth', S.lw); %#ok<AGROW>
end
xlim(ax, [0.2 2.6]); ylim(ax, [-0.03 1.03]); xlabel(ax, 'initial gain g'); ylabel(ax, 'fraction of steps clipped');
legend(ax, hl, {'delay 10', 'delay 20'}, 'Location', 'northwest', 'Box', 'off', 'FontSize', S.fs - 2);
style_axes(ax, 'd  gradient clipping, first 200 iterations');
save_fig(fh, 'Fig3_training', 17, 12); close(fh);
end
