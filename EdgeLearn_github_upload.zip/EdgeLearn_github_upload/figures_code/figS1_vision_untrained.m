function figS1_vision_untrained()
%FIGS1_VISION_UNTRAINED  Supplementary Fig. S1: the vision protocol in untrained networks
%   (Experiment F; 64-unit networks, 8 per condition).
%   a  largest Lyapunov exponent of each network: healthy (natural input), deprived
%      (input amplitude 0.25) before and after homeostatic scaling of the recurrent
%      weights; lines join the same network
%   b,c iterations to learn the restored, prosthetic input (new input weights,
%      amplitude a) for delay 10 (b) and 20 (c), with scaling reversed before
%      training (healthy) or kept (adapted); median and interquartile range
%   d  per network and signal strength: learning time with scaling kept / reversed,
%      versus the network's homeostatic scaling factor
here = fileparts(mfilename('fullpath')); addpath(fullfile(here, '..', 'src'));
S = fig_style(); fh = figure('Visible', 'off', 'Color', 'w');
F = load_runs('expF'); d = dir(fullfile(here, '..', 'results', 'expF', 'run_*.mat'));
amp = nan(numel(d), 1); ad = amp; th = amp; ldep = amp;
for i = 1:numel(d)
  o = load(fullfile(d(i).folder, d(i).name)); o = o.o;
  amp(i) = o.amp; ad(i) = o.adapted; th(i) = o.theta; ldep(i) = o.lam_depr;
end
seeds = 1:8; N = 64; L = nan(3, 8); TH = nan(1, 8);
for s = seeds
  set_seed(s); W = randn(N) / sqrt(N); win = randn(N, 1);
  L(1, s) = lyap_rnn(W, win, s);
  r0 = find(F.seed == s & ad == 0 & amp == 1 & F.k == 10, 1); r1 = find(F.seed == s & ad == 1 & amp == 1 & F.k == 10, 1);
  L(2, s) = ldep(r0); L(3, s) = ldep(r1); TH(s) = th(r1);
end
% a
ax = subplot(2, 2, 1); hold(ax, 'on'); cc = [S.col(1, :); 0.55 0.55 0.55; [0.70 0.12 0.12]];
for s = seeds, plot(ax, 1:3, L(:, s), '-', 'Color', [0.8 0.8 0.8], 'LineWidth', 0.8); end
for j = 1:3, plot(ax, j * ones(1, 8), L(j, :), S.mk{1}, 'Color', cc(j, :), 'MarkerFaceColor', cc(j, :), 'MarkerSize', S.ms); end
for j = 1:3, plot(ax, j + [-0.18 0.18], median(L(j, :)) * [1 1], '-', 'Color', S.ink, 'LineWidth', 2); end
line(ax, [0.5 3.5], [0 0], 'Color', S.ink2, 'LineStyle', '--');
text(ax, 3.12, 0.03, 'edge', 'Color', S.ink2, 'FontSize', S.fs - 1);
set(ax, 'XTick', 1:3, 'XTickLabel', {'healthy', 'deprived', '+ scaling'});
xlim(ax, [0.5 3.5]); ylim(ax, [-0.42 0.08]); ylabel(ax, '\lambda (per step)');
style_axes(ax, 'a  deprivation and scaling: towards the edge');
% b, c
for p = 1:2
  kk = [10 20]; k = kk(p); ax = subplot(2, 2, p + 1); hold(ax, 'on'); hl = [];
  as = [0.25 0.5 1]; mk = {'o', 's'}; col = [S.col(1, :); 0.70 0.12 0.12]; dx = [-0.02 0.02];
  for st = 0:1
    md = nan(1, 3); q1 = md; q3 = md;
    for j = 1:3
      h = sort(F.hit(F.k == k & ad == st & abs(amp - as(j)) < 1e-9)); n = numel(h);
      md(j) = median(h); q1(j) = h(round(0.25 * n + 0.5)); q3(j) = h(round(0.75 * n + 0.5));
      line(ax, (as(j) + dx(st + 1)) * [1 1], [q1(j) q3(j)], 'Color', 0.5 * col(st + 1, :) + 0.5, 'LineWidth', 1.4);
    end
    hl(st + 1) = plot(ax, as + dx(st + 1), md, ['-' mk{st + 1}], 'Color', col(st + 1, :), 'MarkerFaceColor', col(st + 1, :), 'MarkerSize', S.ms, 'LineWidth', S.lw); %#ok<AGROW>
  end
  set(ax, 'XScale', 'log', 'YScale', 'log', 'XTick', as, 'XTickLabel', {'0.25', '0.5', '1'});
  xlim(ax, [0.2 1.25]); ylim(ax, [10 600]); set(ax, 'YTick', [10 25 50 100 200 400], 'YTickLabel', {'10', '25', '50', '100', '200', '400'}); xlabel(ax, 'prosthetic signal strength a'); ylabel(ax, 'iterations to learn');
  legend(ax, hl, {'scaling reversed', 'scaling kept'}, 'Location', 'northwest', 'Box', 'off', 'FontSize', S.fs - 2);
  style_axes(ax, sprintf('%s  learning the new code, delay %d', char('a' + p), k));
end
% d
ax = subplot(2, 2, 4); hold(ax, 'on'); kc = [0.106 0.60 0.42; 0.93 0.55 0.10]; hl = [];
for p = 1:2
  kk = [10 20]; k = kk(p); R = [];
  for s = seeds
    for a = [0.25 0.5 1]
      h0 = F.hit(F.k == k & ad == 0 & abs(amp - a) < 1e-9 & F.seed == s); h1 = F.hit(F.k == k & ad == 1 & abs(amp - a) < 1e-9 & F.seed == s);
      R(end + 1, :) = [TH(s) h1 / h0]; %#ok<AGROW>
    end
  end
  hl(p) = plot(ax, R(:, 1) + 0.006 * (p - 1.5), R(:, 2), S.mk{p + 1}, 'Color', kc(p, :), 'MarkerFaceColor', kc(p, :), 'MarkerSize', S.ms - 1); %#ok<AGROW>
end
line(ax, [1.05 1.5], [1 1], 'Color', S.ink2, 'LineStyle', '--');
set(ax, 'YScale', 'log', 'YTick', [0.5 1 2 3], 'YTickLabel', {'0.5', '1', '2', '3'}); ylim(ax, [0.5 3]); xlim(ax, [1.05 1.5]);
xlabel(ax, 'homeostatic scaling factor \theta'); ylabel(ax, 'learning time, kept / reversed');
legend(ax, hl, {'delay 10', 'delay 20'}, 'Location', 'northwest', 'Box', 'off', 'FontSize', S.fs - 2);
style_axes(ax, 'd  relearning slow-down versus scaling');
save_fig(fh, 'FigS1_vision_untrained', 17, 12); close(fh);
end
