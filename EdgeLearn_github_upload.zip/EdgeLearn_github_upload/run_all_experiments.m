function run_all_experiments()
%RUN_ALL_EXPERIMENTS  Run every simulation of the paper (resumable; about 4 h on
%   two cores with GNU Octave). Scans B, D and E store one file per run and skip
%   runs that already exist; they can also be split over sessions, e.g.
%   expB_bptt(1,2) and expB_bptt(2,2) in two sessions.
here = fileparts(mfilename('fullpath')); addpath(fullfile(here, 'src'), fullfile(here, 'experiments'));
expA_reservoir();      % readout learning, fixed networks (N = 200)
expB_bptt();           % whole-network learning, delays 5, 10, 20
expC_gradients();      % error-signal propagation, example traces
expD_robustness();     % network size, learning rate, nonlinear task
expE_prediction();     % delay 5 at fine resolution; delay-30 test of the fitted rule
expF_vision();         % deprivation and prosthetic code in untrained networks (Fig. S1)
expF2_pretrained();    % the same in networks that first learned the task (Fig. 6)
expG_diagnostics();    % gradients, exponents and independent test during training (Fig. 3)
expA2_feasibility();   % achievable readout accuracy and speed towards it (Fig. 4)
end
