function make_all_figures()
%MAKE_ALL_FIGURES  Regenerate Figs 1-6 and S1 from the saved results and print every
%   number quoted in the text (output also saved in results/stats_output.txt).
here = fileparts(mfilename('fullpath')); addpath(fullfile(here, 'src'), fullfile(here, 'figures_code'));
% the per-run results are stored zipped (GitHub web upload limit); unpack once
if ~exist(fullfile(here, 'results', 'expB'), 'dir')
  unzip(fullfile(here, 'results', 'results_runs.zip'), fullfile(here, 'results'));
end
fig1_concept(); fig2_bptt(); fig3_training(); fig4_readout(); fig5_robustness(); fig6_vision(); figS1_vision_untrained();
stats_for_text();
end
