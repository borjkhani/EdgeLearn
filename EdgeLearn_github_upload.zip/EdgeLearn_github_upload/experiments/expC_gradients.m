function expC_gradients()
%EXPC_GRADIENTS  How far back can an error signal reach?
%   For untrained tanh RNNs (N = 64, as in Experiment B) driven by random input,
%   propagate a random unit perturbation through the Jacobians and record its
%   norm after tau steps (geometric mean over 8 seeds x 20 start times). This is the
%   factor by which a backpropagated error from tau steps later is scaled.
%   Also stores example activity traces for three gains (input on, then off).
here = fileparts(mfilename('fullpath')); addpath(fullfile(here, '..', 'src'));
gs = [0.5 0.8 1.0 1.2 1.6 2.5]; taus = 0:60; N = 64; R = struct('gs', gs, 'taus', taus);
R.lognorm = nan(numel(gs), numel(taus));
for a = 1:numel(gs)
  L = [];
  for s = 1:8
    set_seed(s); W = gs(a) * randn(N) / sqrt(N); win = randn(N, 1);
    set_seed(s + 900); u = 2 * rand(1, 2000) - 1; h = zeros(N, 1); H = zeros(N, 2000);
    for t = 1:2000, h = tanh(W * h + win * u(t)); H(:, t) = h; end
    for t0 = 300:80:1820
      v = randn(N, 1); v = v / norm(v); l = zeros(1, numel(taus));
      for j = 2:numel(taus), v = (1 - H(:, t0 + j - 1).^2) .* (W * v); l(j) = log(norm(v)); end
      L(end + 1, :) = l; %#ok<AGROW>
    end
  end
  R.lognorm(a, :) = mean(L, 1);
end
% example traces: random input for 40 steps, then input off; how long does the
% network keep a trace of it?
R.ex_g = [0.5 0.8 2.5]; R.ex = cell(1, 3); Tx = 160; R.ex_off = 40;
for a = 1:3
  set_seed(3); W = R.ex_g(a) * randn(N) / sqrt(N); win = randn(N, 1);
  set_seed(77); u = 2 * rand(1, Tx) - 1; u(R.ex_off + 1:end) = 0; h = zeros(N, 1); H = zeros(N, Tx);
  for t = 1:Tx, h = tanh(W * h + win * u(t)); H(:, t) = h; end
  R.ex{a} = H(1:4, :); R.ex_u = u;
end
save(fullfile(here, '..', 'results', 'expC_gradients.mat'), 'R');
disp(R.lognorm(:, [11 31 61]));
end
