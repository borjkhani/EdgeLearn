function expF2_pretrained(part, nparts, rev)
%EXPF2_PRETRAINED  Relearning after deprivation in networks that had first learned
%   the task. (1) A healthy network (gain 1) is trained by BPTT to recall its
%   natural input 10 steps back (criterion plus 500 iterations). (2) Deprivation:
%   input amplitude x 0.25; the homeostatic factor theta on the trained recurrent
%   weights restores the healthy mean squared activity. (3) Restoration with the
%   same input code or a new (prosthetic) code, at strength 0.25 or 1, with the
%   scaling kept or reversed, and with the input weights trainable or frozen;
%   the trained readout is kept. Iterations to the criterion are recorded (test
%   error every 5 iterations; 0 if the criterion is met before any update, i.e. no
%   relearning is needed).
if nargin < 1, part = 1; nparts = 1; end
if nargin < 3, rev = false; end
here = fileparts(mfilename('fullpath')); addpath(fullfile(here, '..', 'src'));
od = fullfile(here, '..', 'results', 'expF2'); if ~exist(od, 'dir'), mkdir(od); end
N = 64; k = 10;
[C, Sc, A, Fz, S] = ndgrid([0 1], [0 1], [0.25 1], [0 1], 1:8);   % code new?, scaling kept?, amp, frozen?, seed
jobs = [C(:) Sc(:) A(:) Fz(:) S(:)];
order = part:nparts:size(jobs, 1); if rev, order = fliplr(order); end
for j = order
  f = fullfile(od, sprintf('run_%03d.mat', j)); if exist(f, 'file'), continue; end
  newc = jobs(j, 1); kept = jobs(j, 2); a = jobs(j, 3); fz = jobs(j, 4); s = jobs(j, 5);
  Pt = pretrained(od, N, k, s);
  [W, win, b] = Pt.P{1:3};
  theta = 1; if kept, theta = Pt.theta; end
  w_in = win; if newc, set_seed(s + 77); w_in = randn(N, 1) * norm(win) / sqrt(N); end
  P0 = Pt.P; P0{1} = theta * W; P0{2} = a * w_in;
  opt = struct('T', k + 30, 'batch', 32, 'iters', 3000, 'lr', 3e-3, 'clip', 1, 'every', 5, ...
               'crit', 0.1, 'extra', 100, 'P0', {P0}, 'freeze_in', fz == 1);
  o = train_bptt(N, 1, s + 100, struct('k', k), opt);
  o.err0 = o.err_init; if o.err0 < 0.1, o.it_hit = 0; end      % already meets the criterion
  o.new_code = newc; o.kept = kept; o.amp = a; o.frozen = fz; o.seed = s; o.theta = Pt.theta; o.k = k; o.g = 1;
  o.lam0 = lyap_rnn(theta * W, a * w_in, s, b);
  save(f, 'o');                              % learning curve kept (matched-error analysis)
  printf('[%d] new=%d kept=%d a=%.2f frozen=%d s=%d theta=%.2f err0=%.3f hit=%g\n', j, newc, kept, a, fz, s, Pt.theta, o.err0, o.it_hit); fflush(stdout);
end
end

function Pt = pretrained(od, N, k, s)
% train the healthy network once per seed and compute its homeostatic factor
f = fullfile(od, sprintf('pretrained_%d.mat', s));
if exist(f, 'file'), L = load(f); Pt = L.Pt; return; end
opt = struct('T', k + 30, 'batch', 32, 'iters', 3000, 'lr', 3e-3, 'clip', 1, 'every', 25, 'crit', 0.1, 'extra', 500);
[o, P] = train_bptt(N, 1, s, struct('k', k), opt);
[W, win, b] = P{1:3};
set_seed(s + 300); h = zeros(N, 1); m = 0;
for t = 1:3000, h = tanh(W * h + win * (2 * rand - 1) + b); if t > 500, m = m + mean(h.^2); end, end
Pt.target = m / 2500; Pt.theta = homeo_theta(W, win, 0.25, Pt.target, s, b); Pt.P = P; Pt.hit = o.it_hit;
Pt.lam_trained = lyap_rnn(W, win, s, b); Pt.lam_depr0 = lyap_rnn(W, 0.25 * win, s, b); Pt.lam_depr = lyap_rnn(Pt.theta * W, 0.25 * win, s, b);
save(f, 'Pt');
end
