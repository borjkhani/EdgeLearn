function expF_vision(part, nparts, rev)
%EXPF_VISION  Learning to use a prosthetic input after visual deprivation.
%   A healthy 64-unit network (initial gain 1) receives natural input through
%   input weights win. Deprivation: the input amplitude falls to 0.25 and
%   multiplicative homeostatic scaling of the recurrent weights (factor theta,
%   homeo_theta) restores the healthy mean squared activity. Restoration: input
%   arrives through new, random input weights (a prosthetic code that activates
%   different cells) with amplitude a = 0.25, 0.5 or 1. The network, either
%   healthy (theta = 1, i.e. scaling reversed before rehabilitation) or adapted
%   (theta from deprivation), is then trained by BPTT to recall the restored
%   input k = 10 or 20 steps back. 8 networks per condition. The test error is
%   evaluated every 5 (k = 10) or 10 (k = 20) iterations.
if nargin < 1, part = 1; nparts = 1; end
if nargin < 3, rev = false; end
here = fileparts(mfilename('fullpath')); addpath(fullfile(here, '..', 'src'));
od = fullfile(here, '..', 'results', 'expF'); if ~exist(od, 'dir'), mkdir(od); end
amps = [0.25 0.5 1]; states = [0 1]; ks = [10 20]; seeds = 1:8; N = 64;
[A, St, K, S] = ndgrid(amps, states, ks, seeds); jobs = [A(:) St(:) K(:) S(:)];
order = part:nparts:size(jobs, 1); if rev, order = fliplr(order); end
for j = order
  f = fullfile(od, sprintf('run_%03d.mat', j)); if exist(f, 'file'), continue; end
  a = jobs(j, 1); st = jobs(j, 2); k = jobs(j, 3); s = jobs(j, 4);
  set_seed(s); W = randn(N) / sqrt(N); win = randn(N, 1);         % healthy network, g = 1
  target = healthy_level(W, win, s);
  theta = 1; if st == 1, theta = homeo_theta(W, win, 0.25, target, s); end
  set_seed(s + 77); win2 = randn(N, 1);                            % prosthetic input code
  ev = 5; if k == 20, ev = 10; end                                 % fine time resolution
  opt = struct('T', k + 30, 'batch', 32, 'iters', 3000, 'lr', 3e-3, 'clip', 1, 'every', ev, ...
               'crit', 0.1, 'extra', 100, 'W0', theta * W, 'win0', a * win2);
  o = train_bptt(N, 1, s, struct('k', k), opt);
  o.lam0 = lyap_rnn(theta * W, a * win2, s); o.lam_depr = lyap_rnn(theta * W, 0.25 * win, s);
  o.theta = theta; o.amp = a; o.adapted = st; o.k = k; o.seed = s; o.g = theta;
  save(f, 'o');
  printf('[%d/%d] amp=%.2f adapted=%d k=%d s=%d theta=%.2f lam0=%.3f hit=%g\n', j, size(jobs, 1), a, st, k, s, theta, o.lam0, o.it_hit);
  fflush(stdout);
end
end

function m = healthy_level(W, win, s)
set_seed(s + 300); N = size(W, 1); h = zeros(N, 1); m = 0;
for t = 1:3000
  h = tanh(W * h + win * (2 * rand - 1)); if t > 500, m = m + mean(h.^2); end
end
m = m / 2500;
end
