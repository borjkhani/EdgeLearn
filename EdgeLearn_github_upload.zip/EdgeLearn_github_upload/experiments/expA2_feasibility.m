function expA2_feasibility()
%EXPA2_FEASIBILITY  Separate what a readout can achieve from how fast it gets there.
%   Same networks, inputs and noise as Experiment A. For every gain, network and
%   delay (5, 10, 20): the best achievable test NMSE of a linear readout (ridge
%   regression on the full training set) and the number of samples the online
%   rule (normalised LMS) needs to achieve 90% of that network's own achievable
%   improvement, NMSE <= opt + 0.1 (1 - opt), checked every 100 samples. Conditions
%   whose optimum is not below 0.9 are marked infeasible.
here = fileparts(mfilename('fullpath')); addpath(fullfile(here, '..', 'src'));
gs = 0.3:0.1:2.5; seeds = 1:10; N = 200; wo = 200; Ttr = 20000; Tte = 4000; kl = [5 10 20]; K = 60; chk = 100;
R = struct('gs', gs, 'seeds', seeds, 'kl', kl);
[R.opt, R.trel, R.crit_rel] = deal(nan(numel(gs), numel(seeds), numel(kl)));
for a = 1:numel(gs)
  for s = seeds
    net = make_net(N, gs(a), s);
    set_seed(100 + s); u = 2 * rand(1, Ttr + Tte + wo) - 1;
    X = run_net(net, u, s, wo); u = u(wo + 1:end);
    X = [X; ones(1, size(X, 2))]; Xt = X(:, K + 1:Ttr); Xs = X(:, Ttr + 1:end);
    C = Xt * Xt' / size(Xt, 2); Ci = inv(C + 1e-6 * trace(C) / (N + 1) * eye(N + 1));
    for j = 1:numel(kl)
      k = kl(j); yt = u((K + 1:Ttr) - k); ys = u((Ttr + 1:Ttr + Tte) - k); vy = var(ys);
      w = Ci * (Xt * yt' / size(Xt, 2)); op = mean((w' * Xs - ys).^2) / vy; R.opt(a, s, j) = op;
      cr = op + 0.1 * (1 - op); R.crit_rel(a, s, j) = cr;
      if op > 0.9, continue; end
      w = zeros(N + 1, 1); hit = Inf;
      for t = 1:size(Xt, 2)
        x = Xt(:, t); e = yt(t) - w' * x; w = w + 0.5 * e * x / (x' * x);
        if mod(t, chk) == 0 && mean((w' * Xs - ys).^2) / vy <= cr, hit = t; break; end
      end
      R.trel(a, s, j) = hit;
    end
  end
  printf('g=%.1f opt NMSE (k=5,10,20) %s  t_rel %s\n', gs(a), sprintf('%.2f ', squeeze(median(R.opt(a, :, :), 2))), sprintf('%g ', squeeze(median(R.trel(a, :, :), 2)))); fflush(stdout);
end
save(fullfile(here, '..', 'results', 'expA2_feasibility.mat'), 'R');
end
