function expD_robustness(part, nparts)
%EXPD_ROBUSTNESS  Is the fastest-learning gain robust to network size, learning
%   rate and task? Delay-10 recall with N = 32 and 128 (lr 3e-3), N = 64 with
%   lr = 1e-3 and 1e-2, and a nonlinear task (product u(t-5)*u(t-10), N = 64).
if nargin < 1, part = 1; nparts = 1; end
here = fileparts(mfilename('fullpath')); addpath(fullfile(here, '..', 'src'));
od = fullfile(here, '..', 'results', 'expD'); if ~exist(od, 'dir'), mkdir(od); end
gs = [0.3 0.6 0.9 1.0 1.2 1.6 2.0 2.5]; seeds = 1:5;
cond = {struct('name', 'N32', 'N', 32, 'lr', 3e-3, 'k', 10), ...
        struct('name', 'N128', 'N', 128, 'lr', 3e-3, 'k', 10), ...
        struct('name', 'lr1e-3', 'N', 64, 'lr', 1e-3, 'k', 10), ...
        struct('name', 'lr1e-2', 'N', 64, 'lr', 1e-2, 'k', 10), ...
        struct('name', 'product', 'N', 64, 'lr', 3e-3, 'k', [5 10])};
[C, G, S] = ndgrid(1:numel(cond), 1:numel(gs), seeds); jobs = [C(:) G(:) S(:)];
for j = part:nparts:size(jobs, 1)
  f = fullfile(od, sprintf('run_%03d.mat', j)); if exist(f, 'file'), continue; end
  c = cond{jobs(j, 1)}; g = gs(jobs(j, 2)); s = jobs(j, 3);
  opt = struct('T', max(c.k) + 30, 'batch', 32, 'iters', 3000, 'lr', c.lr, 'clip', 1, 'every', 25, 'crit', 0.1, 'extra', 500);
  if numel(c.k) == 2, opt.crit = 0.2; end
  o = train_bptt(c.N, g, s, struct('k', c.k), opt);
  set_seed(s); W = g * randn(c.N) / sqrt(c.N); win = randn(c.N, 1); o.lam0 = lyap_rnn(W, win, s);
  o.g = g; o.seed = s; o.cond = c.name; save(f, 'o');
  printf('[%d/%d] %s g=%.1f s=%d hit=%g final=%.3f\n', j, size(jobs, 1), c.name, g, s, o.it_hit, o.final); fflush(stdout);
end
end
