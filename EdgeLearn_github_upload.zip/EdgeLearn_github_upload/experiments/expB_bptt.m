function expB_bptt(part, nparts)
%EXPB_BPTT  Whole-network gradient training (BPTT, Adam) from different initial gains.
%   Delayed-recall tasks with delays 5, 10, 20; N = 64; 8 seeds. Saves one file per
%   run in results/expB/ so the scan can be resumed and split over sessions.
if nargin < 1, part = 1; nparts = 1; end
here = fileparts(mfilename('fullpath')); addpath(fullfile(here, '..', 'src'));
od = fullfile(here, '..', 'results', 'expB'); if ~exist(od, 'dir'), mkdir(od); end
gs = [0.3 0.5 0.7 0.8 0.9 1.0 1.1 1.2 1.4 1.6 2.0 2.5]; ks = [5 10 20]; seeds = 1:8;
[G, K, S] = ndgrid(gs, ks, seeds); jobs = [G(:) K(:) S(:)];
for j = part:nparts:size(jobs, 1)
  f = fullfile(od, sprintf('run_%03d.mat', j)); if exist(f, 'file'), continue; end
  g = jobs(j, 1); k = jobs(j, 2); s = jobs(j, 3);
  opt = struct('T', k + 30, 'batch', 32, 'iters', 3000, 'lr', 3e-3, 'clip', 1, 'every', 25, 'crit', 0.1, 'extra', 500);
  o = train_bptt(64, g, s, struct('k', k), opt);
  % conditional Lyapunov exponent of the initial network (same input statistics)
  set_seed(s); W = g * randn(64) / sqrt(64); win = randn(64, 1);
  o.lam0 = lyap_rnn(W, win, s);
  o.g = g; o.k = k; o.seed = s; save(f, 'o');
  printf('[%d/%d] g=%.1f k=%d s=%d hit=%g final=%.3f lam0=%.3f\n', j, size(jobs, 1), g, k, s, o.it_hit, o.final, o.lam0);
  fflush(stdout);
end
end

