function expG_diagnostics(part, nparts, rev)
%EXPG_DIAGNOSTICS  Repeat the whole-network runs of Experiment B (delays 10 and 20,
%   same networks, inputs and batches) while recording: the gradient norm before
%   clipping at every iteration (and hence how often clipping was active), the
%   Lyapunov exponent of the network every 250 iterations during training, and
%   the error on 2000 fresh sequences, never used for stopping, when the criterion
%   was first reached.
if nargin < 1, part = 1; nparts = 1; end
if nargin < 3, rev = false; end
here = fileparts(mfilename('fullpath')); addpath(fullfile(here, '..', 'src'));
od = fullfile(here, '..', 'results', 'expG'); if ~exist(od, 'dir'), mkdir(od); end
gs = [0.3 0.5 0.7 0.8 0.9 1.0 1.1 1.2 1.4 1.6 2.0 2.5]; ks = [10 20]; seeds = 1:8;
[G, K, S] = ndgrid(gs, ks, seeds); jobs = [G(:) K(:) S(:)];
order = part:nparts:size(jobs, 1); if rev, order = fliplr(order); end
for j = order
  f = fullfile(od, sprintf('run_%03d.mat', j)); if exist(f, 'file'), continue; end
  g = jobs(j, 1); k = jobs(j, 2); s = jobs(j, 3);
  opt = struct('T', k + 30, 'batch', 32, 'iters', 3000, 'lr', 3e-3, 'clip', 1, 'every', 25, 'crit', 0.1, 'extra', 500, 'diag', true);
  o = train_bptt(64, g, s, struct('k', k), opt);
  o.g = g; o.k = k; o.seed = s; o = rmfield(o, 'curve'); save(f, 'o');
  printf('[%d] g=%.1f k=%d s=%d hit=%g clip=%.2f lam %s\n', j, g, k, s, o.it_hit, mean(o.gnorm(1:o.iters_run) > 1), sprintf('%.2f ', o.lam_t)); fflush(stdout);
end
end
