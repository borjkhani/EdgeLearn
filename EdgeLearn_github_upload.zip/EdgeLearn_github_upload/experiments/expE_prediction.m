function expE_prediction(part, nparts, rev)
%EXPE_PREDICTION  (1) Delay 5 at finer time resolution (test error every 5
%   iterations), all gains, 8 seeds. (2) Out-of-sample test of the rule found in
%   Experiment B: delay 30, gains 0.8-2.0, 8 seeds, up to 6000 iterations.
%   (Delay 40 was not learned at any gain within this budget; see
%   results/NOTE_delay40.txt.)
if nargin < 1, part = 1; nparts = 1; end
if nargin < 3, rev = false; end   % rev: work from the end of the job list (a second session)
here = fileparts(mfilename('fullpath')); addpath(fullfile(here, '..', 'src'));
od = fullfile(here, '..', 'results', 'expE'); if ~exist(od, 'dir'), mkdir(od); end
g1 = [0.3 0.5 0.7 0.8 0.9 1.0 1.1 1.2 1.4 1.6 2.0 2.5]; g2 = [0.8 1.0 1.2 1.3 1.4 1.5 1.6 1.8 2.0];
jobs = [];
for s = 1:8, for g = g1, jobs(end + 1, :) = [g 5 s]; end, end %#ok<AGROW>
for s = 1:8, for g = g2, jobs(end + 1, :) = [g 30 s]; end, end %#ok<AGROW>
order = part:nparts:size(jobs, 1); if rev, order = fliplr(order); end
for j = order
  f = fullfile(od, sprintf('run_%03d.mat', j)); if exist(f, 'file'), continue; end
  g = jobs(j, 1); k = jobs(j, 2); s = jobs(j, 3);
  if k == 5, opt = struct('T', 35, 'batch', 32, 'iters', 1000, 'lr', 3e-3, 'clip', 1, 'every', 5, 'crit', 0.1, 'extra', 100);
  else,      opt = struct('T', 60, 'batch', 32, 'iters', 6000, 'lr', 3e-3, 'clip', 1, 'every', 50, 'crit', 0.1, 'extra', 200); end
  o = train_bptt(64, g, s, struct('k', k), opt);
  set_seed(s); W = g * randn(64) / sqrt(64); win = randn(64, 1); o.lam0 = lyap_rnn(W, win, s);
  o.g = g; o.k = k; o.seed = s; save(f, 'o');
  printf('[%d/%d] g=%.1f k=%d s=%d hit=%g final=%.3f\n', j, size(jobs, 1), g, k, s, o.it_hit, o.final); fflush(stdout);
end
end
