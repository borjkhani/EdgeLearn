function expA_reservoir()
%EXPA_RESERVOIR  Fixed random network, trained readout (reservoir computing).
%   For each gain g and network seed: autonomous and conditional Lyapunov exponents,
%   delay-resolved memory (ridge readout, delays 1..60), participation ratio of the
%   state covariance, and the learning time of an online (normalised LMS) readout for
%   delays 5, 10 and 20: number of samples until the test NMSE first falls below
%   0.2 (or Inf if never within the budget).
addpath(fullfile(fileparts(mfilename('fullpath')), '..', 'src'));
gs = 0.3:0.1:2.5; seeds = 1:10; N = 200; wo = 200; Ttr = 20000; Tte = 4000;
ks = 1:60; kl = [5 10 20]; crit = 0.2; chk = 100;
R = struct('gs', gs, 'seeds', seeds, 'ks', ks, 'kl', kl, 'crit', crit);
[R.lam_aut, R.lam_cond, R.PR] = deal(nan(numel(gs), numel(seeds)));
R.MCk = nan(numel(gs), numel(seeds), numel(ks)); R.tlearn = nan(numel(gs), numel(seeds), numel(kl));
for a = 1:numel(gs)
  for s = seeds
    net = make_net(N, gs(a), s);
    [~, R.lam_aut(a, s)] = run_net(net, zeros(1, 3000), s, 1000);
    set_seed(100 + s); u = 2 * rand(1, Ttr + Tte + wo) - 1;
    [X, R.lam_cond(a, s)] = run_net(net, u, s, wo); u = u(wo + 1:end);
    X = [X; ones(1, size(X, 2))]; K = max(ks);
    Xt = X(:, K + 1:Ttr); Xs = X(:, Ttr + 1:end);
    C = Xt * Xt' / size(Xt, 2); ev = eig(C(1:N, 1:N)); R.PR(a, s) = sum(ev)^2 / sum(ev.^2);
    Ci = inv(C + 1e-6 * trace(C) / (N + 1) * eye(N + 1));
    for j = 1:numel(ks)
      k = ks(j); yt = u((K + 1:Ttr) - k); ys = u((Ttr + 1:Ttr + Tte) - k);
      w = Ci * (Xt * yt' / size(Xt, 2)); r = corr((w' * Xs)', ys');
      R.MCk(a, s, j) = max(r, 0)^2;
    end
    for j = 1:numel(kl)
      k = kl(j); yt = u((K + 1:Ttr) - k); ys = u((Ttr + 1:Ttr + Tte) - k); vy = var(ys);
      w = zeros(N + 1, 1); hit = Inf;
      for t = 1:size(Xt, 2)
        x = Xt(:, t); e = yt(t) - w' * x; w = w + 0.5 * e * x / (x' * x);
        if mod(t, chk) == 0 && mean((w' * Xs - ys).^2) / vy < crit, hit = t; break; end
      end
      R.tlearn(a, s, j) = hit;
    end
  end
  printf('g=%.1f  lam_cond %.3f  MC %.1f  tlearn(k=5,10,20) %s\n', gs(a), mean(R.lam_cond(a, :)), ...
         mean(sum(R.MCk(a, :, :), 3)), sprintf('%g ', median(squeeze(R.tlearn(a, :, :)), 1)));
  fflush(stdout);
end
save(fullfile(fileparts(mfilename('fullpath')), '..', 'results', 'expA_reservoir.mat'), 'R');
end
